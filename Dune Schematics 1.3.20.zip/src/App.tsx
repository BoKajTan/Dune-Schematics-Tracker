import { useState, useEffect, useCallback } from 'react';

const TIERS = [
  {
    tier: "Kupfer", tierNum: 1, color: "#b87333",
    items: [
      { id: "combat_neut_smugglerdeserterunique01_boots", name: "Aren's Boots", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique01_boots" },
      { id: "combat_neut_smugglerdeserterunique01_top", name: "Aren's Chestpiece", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique01_top" },
      { id: "combat_neut_smugglerdeserterunique01_gloves", name: "Aren's Gloves", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique01_gloves" },
      { id: "combat_neut_smugglerdeserterunique01_helmet", name: "Aren's Mask", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique01_helmet" },
      { id: "combat_neut_smugglerdeserterunique01_bottom", name: "Aren's Pants", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique01_bottom" },
      { id: "uniquear_burst_01", name: "Aren's Vengeance", url: "https://dune.gaming.tools/items/uniquear_burst_01" },
      { id: "highcapacityliterjon", name: "Hajra Literjon Mk1", url: "https://dune.gaming.tools/items/highcapacityliterjon" },
      { id: "stillsuit_unique_armored_01_boots", name: "Hollower Stillsuit Boots", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_01_boots" },
      { id: "stillsuit_unique_armored_01_top", name: "Hollower Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_01_top" },
      { id: "stillsuit_unique_armored_01_gloves", name: "Hollower Stillsuit Gloves", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_01_gloves" },
      { id: "stillsuit_unique_armored_01_mask", name: "Hollower Stillsuit Mask", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_01_mask" },
      { id: "kindjal_unique_blood_01", name: "Kaleff's Drinker", url: "https://dune.gaming.tools/items/kindjal_unique_blood_01" },
      { id: "sandbikeengine_unique_speed_1", name: "Mohandis Sandbike Engine Mk1", url: "https://dune.gaming.tools/items/sandbikeengine_unique_speed_1" },
      { id: "powerpack_unique_regen_01", name: "Old Sparky Mk1", url: "https://dune.gaming.tools/items/powerpack_unique_regen_01" },
      { id: "miningtool_1h_unique_01", name: "Sim's Cutter", url: "https://dune.gaming.tools/items/miningtool_1h_unique_01" },
      { id: "glidepartialstabilizationbelt", name: "The Emperor's Wings Mk1", url: "https://dune.gaming.tools/items/glidepartialstabilizationbelt" },
      { id: "uniquesda1", name: "Way of the Fallen", url: "https://dune.gaming.tools/items/uniquesda1" },
    ]
  },
  {
    tier: "Eisen", tierNum: 2, color: "#8c8c8c",
    items: [
      { id: "dewreaper_unique_01", name: "Buoyant Reaper Mk2", url: "https://dune.gaming.tools/items/dewreaper_unique_01" },
      { id: "stillsuit_choam_unique_dashed02_top", name: "Desert Dasher Garment", url: "https://dune.gaming.tools/items/stillsuit_choam_unique_dashed02_top" },
      { id: "uniquear_burst_02", name: "Fila's Regret", url: "https://dune.gaming.tools/items/uniquear_burst_02" },
      { id: "highcapacityliterjon_02", name: "Hajra Literjon Mk2", url: "https://dune.gaming.tools/items/highcapacityliterjon_02" },
      { id: "combat_heavy_unique_powerefficient_gloves_02", name: "Iri's Gauntlets", url: "https://dune.gaming.tools/items/combat_heavy_unique_powerefficient_gloves_02" },
      { id: "smg_unique_largemag_02", name: "Legion Tattoo", url: "https://dune.gaming.tools/items/smg_unique_largemag_02" },
      { id: "combat_neut_smugglerdeserterunique02_boots", name: "Mendia's Boots", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique02_boots" },
      { id: "combat_neut_smugglerdeserterunique02_gloves", name: "Mendia's Gauntlets", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique02_gloves" },
      { id: "combat_neut_smugglerdeserterunique02_top", name: "Mendia's Jacket", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique02_top" },
      { id: "combat_neut_smugglerdeserterunique02_bottom", name: "Mendia's Pants", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique02_bottom" },
      { id: "combat_neut_smugglerdeserterunique02_helmet", name: "Mendia's Wrap", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique02_helmet" },
      { id: "stillsuit_unique_armored_02_boots", name: "Menol's Stillsuit Boots", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_02_boots" },
      { id: "stillsuit_unique_armored_02_top", name: "Menol's Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_02_top" },
      { id: "stillsuit_unique_armored_02_gloves", name: "Menol's Stillsuit Gloves", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_02_gloves" },
      { id: "stillsuit_unique_armored_02_mask", name: "Menol's Stillsuit Mask", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_02_mask" },
      { id: "sandbikeengine_unique_speed_2", name: "Mohandis Sandbike Engine Mk2", url: "https://dune.gaming.tools/items/sandbikeengine_unique_speed_2" },
      { id: "sandbikeboost_unique_lessheat_2", name: "Night Rider Sandbike Boost Mk2", url: "https://dune.gaming.tools/items/sandbikeboost_unique_lessheat_2" },
      { id: "combat_neut_atreidesdeserterunique01_boots", name: "Oathbreaker Boots", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique01_boots" },
      { id: "combat_neut_atreidesdeserterunique01_top", name: "Oathbreaker Chestpiece", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique01_top" },
      { id: "combat_neut_atreidesdeserterunique01_gloves", name: "Oathbreaker Gauntlets", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique01_gloves" },
      { id: "combat_neut_atreidesdeserterunique01_helmet", name: "Oathbreaker Headwrap", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique01_helmet" },
      { id: "combat_neut_atreidesdeserterunique01_bottom", name: "Oathbreaker Pants", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique01_bottom" },
      { id: "powerpack_unique_regen_02", name: "Old Sparky Mk2", url: "https://dune.gaming.tools/items/powerpack_unique_regen_02" },
      { id: "miningtool_1h_unique_02", name: "Olef's Quickcutter", url: "https://dune.gaming.tools/items/miningtool_1h_unique_02" },
      { id: "uniquesword", name: "Pseudo Pulse-Sword", url: "https://dune.gaming.tools/items/uniquesword" },
      { id: "bloodsack_unique_durable_02", name: "Scipio's Bloodbag", url: "https://dune.gaming.tools/items/bloodsack_unique_durable_02" },
      { id: "kindjal_unique_blood_02", name: "Scipio's Drinker", url: "https://dune.gaming.tools/items/kindjal_unique_blood_02" },
      { id: "uniquescattergun1", name: "Shredder", url: "https://dune.gaming.tools/items/uniquescattergun1" },
      { id: "combat_light_unique_wormthreat_boots_02", name: "Softstep Boots", url: "https://dune.gaming.tools/items/combat_light_unique_wormthreat_boots_02" },
      { id: "glidepartialstabilizationbelt_02", name: "The Emperor's Wings Mk2", url: "https://dune.gaming.tools/items/glidepartialstabilizationbelt_02" },
      { id: "uniquesda2", name: "Way of the Wanderer", url: "https://dune.gaming.tools/items/uniquesda2" },
    ]
  },
  {
    tier: "Stahl", tierNum: 3, color: "#a8a8b8",
    items: [
      { id: "heavypistol_unique_bleed_03", name: "Artisan Disruptor Pistol", url: "https://dune.gaming.tools/items/heavypistol_unique_bleed_03" },
      { id: "longrifle_unique_poison_03", name: "Assassin's Rifle", url: "https://dune.gaming.tools/items/longrifle_unique_poison_03" },
      { id: "buggyinventory_unique_capacity_03", name: "Bigger Buggy Boot Mk3", url: "https://dune.gaming.tools/items/buggyinventory_unique_capacity_03" },
      { id: "buggyengine_unique_accelerate_03", name: "Bluddshot Buggy Engine Mk3", url: "https://dune.gaming.tools/items/buggyengine_unique_accelerate_03" },
      { id: "dewreaper_unique_02", name: "Buoyant Reaper Mk3", url: "https://dune.gaming.tools/items/dewreaper_unique_02" },
      { id: "miningtool_2h_unique_01", name: "Callie's Breaker", url: "https://dune.gaming.tools/items/miningtool_2h_unique_01" },
      { id: "staticcompactor_unique_compact_03", name: "Compact Compactor Mk3", url: "https://dune.gaming.tools/items/staticcompactor_unique_compact_03" },
      { id: "bodyfluidextractor_unique_water_03", name: "Filter Extractor Mk3", url: "https://dune.gaming.tools/items/bodyfluidextractor_unique_water_03" },
      { id: "buggymining_unique_yieldincrease_03", name: "Focused Buggy Cutteray Mk3", url: "https://dune.gaming.tools/items/buggymining_unique_yieldincrease_03" },
      { id: "bloodsack_unique_durable_03", name: "Glutton's Bloodbag", url: "https://dune.gaming.tools/items/bloodsack_unique_durable_03" },
      { id: "kindjal_unique_blood_03", name: "Glutton's Drinker", url: "https://dune.gaming.tools/items/kindjal_unique_blood_03" },
      { id: "highcapacityliterjon_03", name: "Hajra Literjon Mk3", url: "https://dune.gaming.tools/items/highcapacityliterjon_03" },
      { id: "scanner_unique_body_03", name: "Handheld Life Scanner Mk3", url: "https://dune.gaming.tools/items/scanner_unique_body_03" },
      { id: "combat_neut_smugglerdeserterunique03_boots", name: "Inkvine Boots", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique03_boots" },
      { id: "combat_neut_smugglerdeserterunique03_gloves", name: "Inkvine Gauntlets", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique03_gloves" },
      { id: "combat_neut_smugglerdeserterunique03_top", name: "Inkvine Jacket", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique03_top" },
      { id: "combat_neut_smugglerdeserterunique03_helmet", name: "Inkvine Mask", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique03_helmet" },
      { id: "combat_neut_smugglerdeserterunique03_bottom", name: "Inkvine Pants", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique03_bottom" },
      { id: "combat_neut_atreidesdeserterunique02_boots", name: "Karak's Boots", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique02_boots" },
      { id: "combat_neut_atreidesdeserterunique02_gloves", name: "Karak's Gauntlets", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique02_gloves" },
      { id: "combat_neut_atreidesdeserterunique02_helmet", name: "Karak's Helmet", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique02_helmet" },
      { id: "combat_neut_atreidesdeserterunique02_top", name: "Karak's Jacket", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique02_top" },
      { id: "combat_neut_atreidesdeserterunique02_bottom", name: "Karak's Pants", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique02_bottom" },
      { id: "stillsuit_unique_armored_03_boots", name: "Kel's Stillsuit Boots", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_03_boots" },
      { id: "stillsuit_unique_armored_03_top", name: "Kel's Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_03_top" },
      { id: "stillsuit_unique_armored_03_gloves", name: "Kel's Stillsuit Gloves", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_03_gloves" },
      { id: "stillsuit_unique_armored_03_mask", name: "Kel's Stillsuit Mask", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_03_mask" },
      { id: "sandbikeengine_unique_speed_3", name: "Mohandis Sandbike Engine Mk3", url: "https://dune.gaming.tools/items/sandbikeengine_unique_speed_3" },
      { id: "sandbikeboost_unique_lessheat_3", name: "Night Rider Sandbike Boost Mk3", url: "https://dune.gaming.tools/items/sandbikeboost_unique_lessheat_3" },
      { id: "powerpack_unique_regen_03", name: "Old Sparky Mk3", url: "https://dune.gaming.tools/items/powerpack_unique_regen_03" },
      { id: "buggyboost_unique_lessheat_3", name: "Rattler Boost Module Mk3", url: "https://dune.gaming.tools/items/buggyboost_unique_lessheat_3" },
      { id: "combat_light_unique_dewreap_gloves_03", name: "Reaper Gloves", url: "https://dune.gaming.tools/items/combat_light_unique_dewreap_gloves_03" },
      { id: "combat_light_unique_reducesuspensor_top_03", name: "Rigged Suspensor Jacket", url: "https://dune.gaming.tools/items/combat_light_unique_reducesuspensor_top_03" },
      { id: "uniquescattergun2", name: "Ripper", url: "https://dune.gaming.tools/items/uniquescattergun2" },
      { id: "uniquedirk", name: "Searing Shiv", url: "https://dune.gaming.tools/items/uniquedirk" },
      { id: "smg_unique_largemag_03", name: "Seb's Kisser", url: "https://dune.gaming.tools/items/smg_unique_largemag_03" },
      { id: "combat_heavy_unique_powerefficient_gloves_03", name: "Shock Gauntlets", url: "https://dune.gaming.tools/items/combat_heavy_unique_powerefficient_gloves_03" },
      { id: "kindjal_unique_stamina_03", name: "Shock-Knife", url: "https://dune.gaming.tools/items/kindjal_unique_stamina_03" },
      { id: "uniquesword_02", name: "Shock-sword", url: "https://dune.gaming.tools/items/uniquesword_02" },
      { id: "combat_light_unique_biomeheat_top_03", name: "Skin-lined Jacket", url: "https://dune.gaming.tools/items/combat_light_unique_biomeheat_top_03" },
      { id: "stillsuit_choam_unique_dashed03_top", name: "Sprinter's Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_choam_unique_dashed03_top" },
      { id: "combat_light_unique_wormthreat_boots_03", name: "Ta'lab Softstep Boots", url: "https://dune.gaming.tools/items/combat_light_unique_wormthreat_boots_03" },
      { id: "glidepartialstabilizationbelt_03", name: "The Emperor's Wings Mk3", url: "https://dune.gaming.tools/items/glidepartialstabilizationbelt_03" },
      { id: "uniquear1", name: "The Tapper", url: "https://dune.gaming.tools/items/uniquear1" },
      { id: "uniquesda3", name: "Way of the Lost", url: "https://dune.gaming.tools/items/uniquesda3" },
      { id: "uniquear_burst_03", name: "Zaal's Companion", url: "https://dune.gaming.tools/items/uniquear_burst_03" },
    ]
  },
  {
    tier: "Aluminium", tierNum: 4, color: "#c0c8d0",
    items: [
      { id: "uniquesmg1", name: "Abulurd's Rapture", url: "https://dune.gaming.tools/items/uniquesmg1" },
      { id: "ornithopterlightlocomotion_unique_speed_4", name: "Albatross Wing Module Mk4", url: "https://dune.gaming.tools/items/ornithopterlightlocomotion_unique_speed_4" },
      { id: "buggyinventory_unique_capacity_04", name: "Bigger Buggy Boot Mk4", url: "https://dune.gaming.tools/items/buggyinventory_unique_capacity_04" },
      { id: "buggyengine_unique_accelerate_04", name: "Bluddshot Buggy Engine Mk4", url: "https://dune.gaming.tools/items/buggyengine_unique_accelerate_04" },
      { id: "dewreaper_unique_03", name: "Buoyant Reaper Mk4", url: "https://dune.gaming.tools/items/dewreaper_unique_03" },
      { id: "uniquethumper", name: "Clapper Mk4", url: "https://dune.gaming.tools/items/uniquethumper" },
      { id: "dewreaper_1h_unique_compact_04", name: "Collapsible Dew Reaper Mk4", url: "https://dune.gaming.tools/items/dewreaper_1h_unique_compact_04" },
      { id: "staticcompactor_unique_compact_04", name: "Compact Compactor Mk4", url: "https://dune.gaming.tools/items/staticcompactor_unique_compact_04" },
      { id: "combat_light_unique_stamina_bottom_04", name: "Compression-Stim Leggings", url: "https://dune.gaming.tools/items/combat_light_unique_stamina_bottom_04" },
      { id: "uniquedirk_02", name: "Denira's Gift", url: "https://dune.gaming.tools/items/uniquedirk_02" },
      { id: "uniquescattergun3", name: "Eviscerator", url: "https://dune.gaming.tools/items/uniquescattergun3" },
      { id: "lmg_unique_rapidfire_04", name: "Experimental Vulcan GAU-94", url: "https://dune.gaming.tools/items/lmg_unique_rapidfire_04" },
      { id: "bodyfluidextractor_unique_water_04", name: "Filter Extractor Mk4", url: "https://dune.gaming.tools/items/bodyfluidextractor_unique_water_04" },
      { id: "uniquescattergun_fire_04", name: "Firestorm", url: "https://dune.gaming.tools/items/uniquescattergun_fire_04" },
      { id: "buggymining_unique_yieldincrease_04", name: "Focused Buggy Cutteray Mk4", url: "https://dune.gaming.tools/items/buggymining_unique_yieldincrease_04" },
      { id: "highcapacityliterjon_04", name: "Hajra Literjon Mk4", url: "https://dune.gaming.tools/items/highcapacityliterjon_04" },
      { id: "shotgun_unique_explosive_04", name: "House Burst Drillshot", url: "https://dune.gaming.tools/items/shotgun_unique_explosive_04" },
      { id: "heavypistol_unique_bleed_04", name: "House Disruptor Pistol", url: "https://dune.gaming.tools/items/heavypistol_unique_bleed_04" },
      { id: "combat_light_unique_wormthreat_boots_04", name: "Idaho Softstep Boots", url: "https://dune.gaming.tools/items/combat_light_unique_wormthreat_boots_04" },
      { id: "combat_light_unique_dewreap_gloves_04", name: "Improved Reaper Gloves", url: "https://dune.gaming.tools/items/combat_light_unique_dewreap_gloves_04" },
      { id: "combat_light_unique_reducesuspensor_top_04", name: "Improved Suspensor Jacket", url: "https://dune.gaming.tools/items/combat_light_unique_reducesuspensor_top_04" },
      { id: "smg_unique_largemag_04", name: "Ironwatch Special", url: "https://dune.gaming.tools/items/smg_unique_largemag_04" },
      { id: "longrifle_unique_poison_04", name: "Long Shot", url: "https://dune.gaming.tools/items/longrifle_unique_poison_04" },
      { id: "stillsuit_unique_efficient_04_boots", name: "Maraqeb Stillsuit Boots", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_04_boots" },
      { id: "stillsuit_unique_efficient_04_top", name: "Maraqeb Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_04_top" },
      { id: "stillsuit_unique_efficient_04_gloves", name: "Maraqeb Stillsuit Gloves", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_04_gloves" },
      { id: "stillsuit_unique_efficient_04_mask", name: "Maraqeb Stillsuit Mask", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_04_mask" },
      { id: "combat_light_unique_biomeheat_top_04", name: "Miner's Blessing", url: "https://dune.gaming.tools/items/combat_light_unique_biomeheat_top_04" },
      { id: "sandbikeengine_unique_speed_4", name: "Mohandis Sandbike Engine Mk4", url: "https://dune.gaming.tools/items/sandbikeengine_unique_speed_4" },
      { id: "sandbikeboost_unique_lessheat_4", name: "Night Rider Sandbike Boost Mk4", url: "https://dune.gaming.tools/items/sandbikeboost_unique_lessheat_4" },
      { id: "powerpack_unique_regen_04", name: "Old Sparky Mk4", url: "https://dune.gaming.tools/items/powerpack_unique_regen_04" },
      { id: "uniquear2", name: "Pipecleaner", url: "https://dune.gaming.tools/items/uniquear2" },
      { id: "uniquerapier", name: "Poison Mist", url: "https://dune.gaming.tools/items/uniquerapier" },
      { id: "combat_heavy_unique_powerefficient_gloves_04", name: "Power Gauntlets", url: "https://dune.gaming.tools/items/combat_heavy_unique_powerefficient_gloves_04" },
      { id: "combat_neut_smugglerdeserterunique04_boots", name: "Quirth's Boots", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique04_boots" },
      { id: "combat_neut_smugglerdeserterunique04_gloves", name: "Quirth's Gauntlets", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique04_gloves" },
      { id: "combat_neut_smugglerdeserterunique04_helmet", name: "Quirth's Helmet", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique04_helmet" },
      { id: "combat_neut_smugglerdeserterunique04_top", name: "Quirth's Jacket", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique04_top" },
      { id: "combat_neut_smugglerdeserterunique04_bottom", name: "Quirth's Pants", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique04_bottom" },
      { id: "buggyboost_unique_lessheat_4", name: "Rattler Boost Module Mk4", url: "https://dune.gaming.tools/items/buggyboost_unique_lessheat_4" },
      { id: "stillsuit_choam_unique_dashed04_top", name: "Sand Strider Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_choam_unique_dashed04_top" },
      { id: "miningtool_2h_unique_02", name: "Sandflies Carver", url: "https://dune.gaming.tools/items/miningtool_2h_unique_02" },
      { id: "combat_neut_atreidesdeserterunique03_boots", name: "Sentinel Boots", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique03_boots" },
      { id: "combat_neut_atreidesdeserterunique03_gloves", name: "Sentinel Gauntlets", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique03_gloves" },
      { id: "combat_neut_atreidesdeserterunique03_helmet", name: "Sentinel Helmet", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique03_helmet" },
      { id: "combat_neut_atreidesdeserterunique03_top", name: "Sentinel Jacket", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique03_top" },
      { id: "combat_neut_atreidesdeserterunique03_bottom", name: "Sentinel Pants", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique03_bottom" },
      { id: "stillsuit_unique_heatmitigation_04_mask", name: "Shadow Hood", url: "https://dune.gaming.tools/items/stillsuit_unique_heatmitigation_04_mask" },
      { id: "kindjal_unique_blood_04", name: "Shadrath's Drinker", url: "https://dune.gaming.tools/items/kindjal_unique_blood_04" },
      { id: "uniquesda_doubleshot_04", name: "Shadrath's Edge", url: "https://dune.gaming.tools/items/uniquesda_doubleshot_04" },
      { id: "stillsuit_unique_armored_04_boots", name: "Shadrath's Stillsuit Boots", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_04_boots" },
      { id: "stillsuit_unique_armored_04_top", name: "Shadrath's Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_04_top" },
      { id: "stillsuit_unique_armored_04_gloves", name: "Shadrath's Stillsuit Gloves", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_04_gloves" },
      { id: "stillsuit_unique_armored_04_mask", name: "Shadrath's Stillsuit Mask", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_04_mask" },
      { id: "bloodsack_unique_durable_04", name: "Sinner's Bloodbag", url: "https://dune.gaming.tools/items/bloodsack_unique_durable_04" },
      { id: "kindjal_unique_stamina_04", name: "Spark-Knife", url: "https://dune.gaming.tools/items/kindjal_unique_stamina_04" },
      { id: "uniquesword_03", name: "Spark-sword", url: "https://dune.gaming.tools/items/uniquesword_03" },
      { id: "uniquear_burst_04", name: "Stammershot", url: "https://dune.gaming.tools/items/uniquear_burst_04" },
      { id: "treadwheelboost_unique_lessheat_4", name: "Steady Treadwheel Boost Module Mk4", url: "https://dune.gaming.tools/items/treadwheelboost_unique_lessheat_4" },
      { id: "ornithopterlightboost_unique_lessheat_4", name: "Stormrider Boost Module Mk4", url: "https://dune.gaming.tools/items/ornithopterlightboost_unique_lessheat_4" },
      { id: "treadwheelengine_unique_speed_4", name: "Swift Treadwheel Engine Mk4", url: "https://dune.gaming.tools/items/treadwheelengine_unique_speed_4" },
      { id: "unique_sword_bleedyblocky_4", name: "Sword of Seven Sorrows", url: "https://dune.gaming.tools/items/unique_sword_bleedyblocky_4" },
      { id: "glidepartialstabilizationbelt_04", name: "The Emperor's Wings Mk4", url: "https://dune.gaming.tools/items/glidepartialstabilizationbelt_04" },
      { id: "uniquesda4", name: "Way of the Fighter", url: "https://dune.gaming.tools/items/uniquesda4" },
    ]
  },
  {
    tier: "Duraluminium", tierNum: 5, color: "#d4af37",
    items: [
      { id: "combat_neut_atreidesdeserterunique04_boots", name: "Acheronian Boots", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique04_boots" },
      { id: "combat_neut_atreidesdeserterunique04_top", name: "Acheronian Chestplate", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique04_top" },
      { id: "combat_neut_atreidesdeserterunique04_gloves", name: "Acheronian Gauntlets", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique04_gloves" },
      { id: "combat_neut_atreidesdeserterunique04_helmet", name: "Acheronian Helmet", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique04_helmet" },
      { id: "combat_neut_atreidesdeserterunique04_bottom", name: "Acheronian Pants", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique04_bottom" },
      { id: "shotgun_unique_explosive_05", name: "Adept Burst Drillshot", url: "https://dune.gaming.tools/items/shotgun_unique_explosive_05" },
      { id: "heavypistol_unique_bleed_05", name: "Adept Disruptor Pistol", url: "https://dune.gaming.tools/items/heavypistol_unique_bleed_05" },
      { id: "combat_light_unique_dewreap_gloves_05", name: "Advanced Reaper Gloves", url: "https://dune.gaming.tools/items/combat_light_unique_dewreap_gloves_05" },
      { id: "combat_light_unique_reducesuspensor_top_05", name: "Advanced Suspensor Jacket", url: "https://dune.gaming.tools/items/combat_light_unique_reducesuspensor_top_05" },
      { id: "ornithopterlightlocomotion_unique_speed_5", name: "Albatross Wing Module Mk5", url: "https://dune.gaming.tools/items/ornithopterlightlocomotion_unique_speed_5" },
      { id: "choamlg1", name: "Arhun K-28 Lasgun", url: "https://dune.gaming.tools/items/choamlg1" },
      { id: "stillsuit_unique_efficient_05_boots", name: "Batigh Stillsuit Boots", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_05_boots" },
      { id: "stillsuit_unique_efficient_05_top", name: "Batigh Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_05_top" },
      { id: "stillsuit_unique_efficient_05_gloves", name: "Batigh Stillsuit Gloves", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_05_gloves" },
      { id: "stillsuit_unique_efficient_05_mask", name: "Batigh Stillsuit Mask", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_05_mask" },
      { id: "benegesserit_armorset", name: "Bene Gesserit Armor Set", url: "https://dune.gaming.tools/items/benegesserit_armorset" },
      { id: "buggyinventory_unique_capacity_05", name: "Bigger Buggy Boot Mk5", url: "https://dune.gaming.tools/items/buggyinventory_unique_capacity_05" },
      { id: "unique_sword_bleedyblocky_5", name: "Bite Back Blade", url: "https://dune.gaming.tools/items/unique_sword_bleedyblocky_5" },
      { id: "buggyengine_unique_accelerate_05", name: "Bluddshot Buggy Engine Mk5", url: "https://dune.gaming.tools/items/buggyengine_unique_accelerate_05" },
      { id: "dewreaper_unique_04", name: "Buoyant Reaper Mk5", url: "https://dune.gaming.tools/items/dewreaper_unique_04" },
      { id: "combat_neut_smugglerdeserterunique05_boots", name: "Chosen Boots", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique05_boots" },
      { id: "combat_neut_smugglerdeserterunique05_top", name: "Chosen Chestplate", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique05_top" },
      { id: "combat_neut_smugglerdeserterunique05_gloves", name: "Chosen Gauntlets", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique05_gloves" },
      { id: "combat_neut_smugglerdeserterunique05_helmet", name: "Chosen Helmet", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique05_helmet" },
      { id: "combat_neut_smugglerdeserterunique05_bottom", name: "Chosen Pants", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique05_bottom" },
      { id: "dewreaper_1h_unique_compact_05", name: "Collapsible Dew Reaper Mk5", url: "https://dune.gaming.tools/items/dewreaper_1h_unique_compact_05" },
      { id: "staticcompactor_unique_compact_05", name: "Compact Compactor Mk5", url: "https://dune.gaming.tools/items/staticcompactor_unique_compact_05" },
      { id: "heavypistol_unique_headshot_05", name: "Cope", url: "https://dune.gaming.tools/items/heavypistol_unique_headshot_05" },
      { id: "stilltent_unique_01", name: "Double-sealed Stilltent", url: "https://dune.gaming.tools/items/stilltent_unique_01" },
      { id: "stillsuit_choam_unique_dashed05_top", name: "Dune Dancer Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_choam_unique_dashed05_top" },
      { id: "lmg_unique_rapidfire_05", name: "Extravagant Message", url: "https://dune.gaming.tools/items/lmg_unique_rapidfire_05" },
      { id: "bodyfluidextractor_unique_water_05", name: "Filter Extractor Mk5", url: "https://dune.gaming.tools/items/bodyfluidextractor_unique_water_05" },
      { id: "longrifle_unique_largemag_05", name: "Fivefinger's Tripleshot Rifle", url: "https://dune.gaming.tools/items/longrifle_unique_largemag_05" },
      { id: "buggymining_unique_yieldincrease_05", name: "Focused Buggy Cutteray Mk5", url: "https://dune.gaming.tools/items/buggymining_unique_yieldincrease_05" },
      { id: "dewreaper_2h_unique_yieldincrease_05", name: "Focused Reaper Mk5", url: "https://dune.gaming.tools/items/dewreaper_2h_unique_yieldincrease_05" },
      { id: "highcapacityliterjon_05", name: "Hajra Literjon Mk5", url: "https://dune.gaming.tools/items/highcapacityliterjon_05" },
      { id: "ornithoptermediumlocomotion_unique_strafe_5", name: "Hummingbird Wing Module Mk5", url: "https://dune.gaming.tools/items/ornithoptermediumlocomotion_unique_strafe_5" },
      { id: "bodyfluidextractor_unique_poison_05", name: "Impure Extractor Mk5", url: "https://dune.gaming.tools/items/bodyfluidextractor_unique_poison_05" },
      { id: "kindjal_unique_stamina_05", name: "Jolt-knife", url: "https://dune.gaming.tools/items/kindjal_unique_stamina_05" },
      { id: "uniquesword_04", name: "Jolt-sword", url: "https://dune.gaming.tools/items/uniquesword_04" },
      { id: "uniquerapier_02", name: "Kharet Viper", url: "https://dune.gaming.tools/items/uniquerapier_02" },
      { id: "scanner_efficient_1", name: "Long Range Scanner", url: "https://dune.gaming.tools/items/scanner_efficient_1" },
      { id: "bloodsack_unique_durable_05", name: "Maas Kharet Bloodbag", url: "https://dune.gaming.tools/items/bloodsack_unique_durable_05" },
      { id: "combat_heavy_unique_reinforced_boots_05", name: "Mendek's Boots", url: "https://dune.gaming.tools/items/combat_heavy_unique_reinforced_boots_05" },
      { id: "combat_heavy_unique_reinforced_top_05", name: "Mendek's Chestplate", url: "https://dune.gaming.tools/items/combat_heavy_unique_reinforced_top_05" },
      { id: "combat_heavy_unique_reinforced_gloves_05", name: "Mendek's Gauntlets", url: "https://dune.gaming.tools/items/combat_heavy_unique_reinforced_gloves_05" },
      { id: "combat_heavy_unique_reinforced_helmet_05", name: "Mendek's Helmet", url: "https://dune.gaming.tools/items/combat_heavy_unique_reinforced_helmet_05" },
      { id: "combat_heavy_unique_reinforced_bottom_05", name: "Mendek's Pants", url: "https://dune.gaming.tools/items/combat_heavy_unique_reinforced_bottom_05" },
      { id: "uniquear_burst_05", name: "Mendek's Rattle", url: "https://dune.gaming.tools/items/uniquear_burst_05" },
      { id: "mentat_lightarmorset", name: "Mentat Light Armor Set", url: "https://dune.gaming.tools/items/mentat_lightarmorset" },
      { id: "sandbikeengine_unique_speed_5", name: "Mohandis Sandbike Engine Mk5", url: "https://dune.gaming.tools/items/sandbikeengine_unique_speed_5" },
      { id: "uniquedirk_03", name: "Moisture Sealer", url: "https://dune.gaming.tools/items/uniquedirk_03" },
      { id: "sandbikeboost_unique_lessheat_5", name: "Night Rider Sandbike Boost Mk5", url: "https://dune.gaming.tools/items/sandbikeboost_unique_lessheat_5" },
      { id: "kindjal_unique_blood_05", name: "Pardot's Drinker", url: "https://dune.gaming.tools/items/kindjal_unique_blood_05" },
      { id: "uniquesmg2", name: "Piter's Disruptor", url: "https://dune.gaming.tools/items/uniquesmg2" },
      { id: "planetologist_lightarmorset", name: "Planetologist Light Armor Set", url: "https://dune.gaming.tools/items/planetologist_lightarmorset" },
      { id: "buggyboost_unique_lessheat_5", name: "Rattler Boost Module Mk5", url: "https://dune.gaming.tools/items/buggyboost_unique_lessheat_5" },
      { id: "smg_unique_largemag_05", name: "Relentless", url: "https://dune.gaming.tools/items/smg_unique_largemag_05" },
      { id: "stillsuit_unique_armored_05_boots", name: "Saturnine Stillsuit Boots", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_05_boots" },
      { id: "stillsuit_unique_armored_05_top", name: "Saturnine Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_05_top" },
      { id: "stillsuit_unique_armored_05_gloves", name: "Saturnine Stillsuit Gloves", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_05_gloves" },
      { id: "stillsuit_unique_armored_05_mask", name: "Saturnine Stillsuit Mask", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_05_mask" },
      { id: "flamethrower_prototype", name: "Scorchbolt", url: "https://dune.gaming.tools/items/flamethrower_prototype" },
      { id: "uniquear3", name: "Scrubber", url: "https://dune.gaming.tools/items/uniquear3" },
      { id: "stillsuit_unique_heatmitigation_05_mask", name: "Shaded Hood", url: "https://dune.gaming.tools/items/stillsuit_unique_heatmitigation_05_mask" },
      { id: "uniqueflamethrower", name: "Shaitan's Tongue", url: "https://dune.gaming.tools/items/uniqueflamethrower" },
      { id: "uniquescattergun_fire_05", name: "Starburst", url: "https://dune.gaming.tools/items/uniquescattergun_fire_05" },
      { id: "combat_light_unique_biomeheat_top_05", name: "Station Garb", url: "https://dune.gaming.tools/items/combat_light_unique_biomeheat_top_05" },
      { id: "combat_heavy_unique_powerefficient_gloves_05", name: "Station Gauntlets", url: "https://dune.gaming.tools/items/combat_heavy_unique_powerefficient_gloves_05" },
      { id: "ornithoptermediumboost_unique_lessheat_5", name: "Steady Assault Boost Module Mk5", url: "https://dune.gaming.tools/items/ornithoptermediumboost_unique_lessheat_5" },
      { id: "treadwheelboost_unique_lessheat_5", name: "Steady Treadwheel Boost Module Mk5", url: "https://dune.gaming.tools/items/treadwheelboost_unique_lessheat_5" },
      { id: "combat_light_unique_stamina_bottom_05", name: "Stim-Leggings", url: "https://dune.gaming.tools/items/combat_light_unique_stamina_bottom_05" },
      { id: "ornithopterlightboost_unique_lessheat_5", name: "Stormrider Boost Module Mk5", url: "https://dune.gaming.tools/items/ornithopterlightboost_unique_lessheat_5" },
      { id: "treadwheelengine_unique_speed_5", name: "Swift Treadwheel Engine Mk5", url: "https://dune.gaming.tools/items/treadwheelengine_unique_speed_5" },
      { id: "swordmaster_heavyarmorset", name: "Swordmaster Heavy Armor Set", url: "https://dune.gaming.tools/items/swordmaster_heavyarmorset" },
      { id: "combat_hark_medunique01_boots", name: "Syndicate Boots", url: "https://dune.gaming.tools/items/combat_hark_medunique01_boots" },
      { id: "combat_hark_medunique01_top", name: "Syndicate Chestplate", url: "https://dune.gaming.tools/items/combat_hark_medunique01_top" },
      { id: "combat_hark_medunique01_gloves", name: "Syndicate Gauntlets", url: "https://dune.gaming.tools/items/combat_hark_medunique01_gloves" },
      { id: "combat_hark_medunique01_helmet", name: "Syndicate Helmet", url: "https://dune.gaming.tools/items/combat_hark_medunique01_helmet" },
      { id: "uniquescattergun4", name: "Syndicate Impaler", url: "https://dune.gaming.tools/items/uniquescattergun4" },
      { id: "combat_hark_medunique01_bottom", name: "Syndicate Pants", url: "https://dune.gaming.tools/items/combat_hark_medunique01_bottom" },
      { id: "uniquesda_doubleshot_05", name: "Taqwa's Double", url: "https://dune.gaming.tools/items/uniquesda_doubleshot_05" },
      { id: "miningtool_2h_unique_03", name: "Tarl Cutteray", url: "https://dune.gaming.tools/items/miningtool_2h_unique_03" },
      { id: "combat_light_unique_wormthreat_boots_05", name: "Tarl Softstep Boots", url: "https://dune.gaming.tools/items/combat_light_unique_wormthreat_boots_05" },
      { id: "glidepartialstabilizationbelt_05", name: "The Emperor's Wings Mk5", url: "https://dune.gaming.tools/items/glidepartialstabilizationbelt_05" },
      { id: "longrifle_unique_poison_05", name: "Thufir's Best", url: "https://dune.gaming.tools/items/longrifle_unique_poison_05" },
      { id: "trooper_heavyarmorset", name: "Trooper Heavy Armor Set", url: "https://dune.gaming.tools/items/trooper_heavyarmorset" },
      { id: "uniquesda5", name: "Way of the Desert", url: "https://dune.gaming.tools/items/uniquesda5" },
      { id: "combat_light_unique_scanning_helmet_05", name: "Wayfinder Helm", url: "https://dune.gaming.tools/items/combat_light_unique_scanning_helmet_05" },
      { id: "powerpack_unique_regen_05", name: "Young Sparky Mk5", url: "https://dune.gaming.tools/items/powerpack_unique_regen_05" },
    ]
  },
  {
    tier: "Plastanium", tierNum: 6, color: "#e8c87a",
    items: [
      { id: "smg_unique_largemag_06", name: "A Dart for Every Man", url: "https://dune.gaming.tools/items/smg_unique_largemag_06" },
      { id: "powerpack_unique_capacity_06", name: "Accelerator Power Pack", url: "https://dune.gaming.tools/items/powerpack_unique_capacity_06" },
      { id: "holtzmanshieldactivedrain_unique_01", name: "Adaptive Holtzman Shield", url: "https://dune.gaming.tools/items/holtzmanshieldactivedrain_unique_01" },
      { id: "ornithopterlightlocomotion_unique_speed_6", name: "Albatross Wing Module Mk6", url: "https://dune.gaming.tools/items/ornithopterlightlocomotion_unique_speed_6" },
      { id: "shotgun_unique_largemag_06", name: "Ambition", url: "https://dune.gaming.tools/items/shotgun_unique_largemag_06" },
      { id: "lmg_unique_rapidfire_06", name: "Bashar's Command", url: "https://dune.gaming.tools/items/lmg_unique_rapidfire_06" },
      { id: "buggyinventory_unique_capacity_06", name: "Bigger Buggy Boot Mk6", url: "https://dune.gaming.tools/items/buggyinventory_unique_capacity_06" },
      { id: "choamlg2", name: "Black Market K-28 Lasgun", url: "https://dune.gaming.tools/items/choamlg2" },
      { id: "buggyengine_unique_accelerate_06", name: "Bluddshot Buggy Engine Mk6", url: "https://dune.gaming.tools/items/buggyengine_unique_accelerate_06" },
      { id: "combat_heavy_unique_reinforced_boots_06", name: "Bulwark Boots", url: "https://dune.gaming.tools/items/combat_heavy_unique_reinforced_boots_06" },
      { id: "combat_heavy_unique_reinforced_top_06", name: "Bulwark Chest", url: "https://dune.gaming.tools/items/combat_heavy_unique_reinforced_top_06" },
      { id: "combat_heavy_unique_reinforced_gloves_06", name: "Bulwark Gloves", url: "https://dune.gaming.tools/items/combat_heavy_unique_reinforced_gloves_06" },
      { id: "combat_heavy_unique_reinforced_helmet_06", name: "Bulwark Helmet", url: "https://dune.gaming.tools/items/combat_heavy_unique_reinforced_helmet_06" },
      { id: "combat_heavy_unique_reinforced_bottom_06", name: "Bulwark Leggings", url: "https://dune.gaming.tools/items/combat_heavy_unique_reinforced_bottom_06" },
      { id: "dewreaper_unique_05", name: "Buoyant Reaper Mk6", url: "https://dune.gaming.tools/items/dewreaper_unique_05" },
      { id: "uniquedualblades_6", name: "Burning Blades", url: "https://dune.gaming.tools/items/uniquedualblades_6" },
      { id: "uniquedirk_04", name: "Cauterizer", url: "https://dune.gaming.tools/items/uniquedirk_04" },
      { id: "combat_heavy_unique_powerefficient_gloves_06", name: "Circuit Gauntlets", url: "https://dune.gaming.tools/items/combat_heavy_unique_powerefficient_gloves_06" },
      { id: "dewreaper_1h_unique_compact_06", name: "Collapsible Dew Reaper Mk6", url: "https://dune.gaming.tools/items/dewreaper_1h_unique_compact_06" },
      { id: "staticcompactor_unique_compact_06", name: "Compact Compactor Mk6", url: "https://dune.gaming.tools/items/staticcompactor_unique_compact_06" },
      { id: "stillsuit_choam_unique_dashed06_top", name: "Crew Chief's Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_choam_unique_dashed06_top" },
      { id: "sandcrawlerlocomotion_unique_wormthreat_06", name: "Dampened Sandcrawler Treads", url: "https://dune.gaming.tools/items/sandcrawlerlocomotion_unique_wormthreat_06" },
      { id: "combat_light_unique_biomeheat_top_06", name: "Desert Garb", url: "https://dune.gaming.tools/items/combat_light_unique_biomeheat_top_06" },
      { id: "longrifle_unique_poison_06", name: "Dunewatcher", url: "https://dune.gaming.tools/items/longrifle_unique_poison_06" },
      { id: "fullsuspensorbelt_unique_durability", name: "Elohim-Class Suspensor Belt", url: "https://dune.gaming.tools/items/fullsuspensorbelt_unique_durability" },
      { id: "combat_neut_atreidesdeserterunique05_boots", name: "Executor's Boots", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique05_boots" },
      { id: "combat_neut_atreidesdeserterunique05_top", name: "Executor's Chestpiece", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique05_top" },
      { id: "combat_neut_atreidesdeserterunique05_gloves", name: "Executor's Gauntlets", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique05_gloves" },
      { id: "combat_neut_atreidesdeserterunique05_helmet", name: "Executor's Helmet", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique05_helmet" },
      { id: "combat_neut_atreidesdeserterunique05_bottom", name: "Executor's Pants", url: "https://dune.gaming.tools/items/combat_neut_atreidesdeserterunique05_bottom" },
      { id: "uniquear6_electric", name: "Experimental Lightning Gun", url: "https://dune.gaming.tools/items/uniquear6_electric" },
      { id: "consumable_buff_poisonstackincrease", name: "Experimental Toxin-Absorption Pills", url: "https://dune.gaming.tools/items/consumable_buff_poisonstackincrease" },
      { id: "kindjal_unique_blood_06", name: "Feyd's Drinker", url: "https://dune.gaming.tools/items/kindjal_unique_blood_06" },
      { id: "bodyfluidextractor_unique_water_06", name: "Filter Extractor Mk6", url: "https://dune.gaming.tools/items/bodyfluidextractor_unique_water_06" },
      { id: "buggymining_unique_yieldincrease_06", name: "Focused Buggy Cutteray Mk6", url: "https://dune.gaming.tools/items/buggymining_unique_yieldincrease_06" },
      { id: "flamethrower_prototype_2", name: "Glasser", url: "https://dune.gaming.tools/items/flamethrower_prototype_2" },
      { id: "highcapacityliterjon_06", name: "Hajra Literjon Mk6", url: "https://dune.gaming.tools/items/highcapacityliterjon_06" },
      { id: "uniquerapier_03", name: "Halleck's Pick", url: "https://dune.gaming.tools/items/uniquerapier_03" },
      { id: "combat_light_unique_climbing_gloves_06", name: "Hook-claw Gloves", url: "https://dune.gaming.tools/items/combat_light_unique_climbing_gloves_06" },
      { id: "ornithoptermediumlocomotion_unique_strafe_6", name: "Hummingbird Wing Module Mk6", url: "https://dune.gaming.tools/items/ornithoptermediumlocomotion_unique_strafe_6" },
      { id: "combat_light_unique_reducesuspensor_top_06", name: "Idaho's Charge", url: "https://dune.gaming.tools/items/combat_light_unique_reducesuspensor_top_06" },
      { id: "stillsuit_unique_armored_06_boots", name: "Imperial Stillsuit Boots", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_06_boots" },
      { id: "stillsuit_unique_armored_06_top", name: "Imperial Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_06_top" },
      { id: "stillsuit_unique_armored_06_gloves", name: "Imperial Stillsuit Gloves", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_06_gloves" },
      { id: "stillsuit_unique_armored_06_mask", name: "Imperial Stillsuit Mask", url: "https://dune.gaming.tools/items/stillsuit_unique_armored_06_mask" },
      { id: "bodyfluidextractor_unique_poison_06", name: "Impure Extractor Mk6", url: "https://dune.gaming.tools/items/bodyfluidextractor_unique_poison_06" },
      { id: "uniquear_burst_06", name: "Indara's Lullaby", url: "https://dune.gaming.tools/items/uniquear_burst_06" },
      { id: "combat_light_unique_stamina_bottom_06", name: "Ix-core Leggings", url: "https://dune.gaming.tools/items/combat_light_unique_stamina_bottom_06" },
      { id: "miningtool_2h_unique_04", name: "Kynes's Cutteray", url: "https://dune.gaming.tools/items/miningtool_2h_unique_04" },
      { id: "sandbikeengine_unique_speed_6", name: "Mohandis Sandbike Engine Mk6", url: "https://dune.gaming.tools/items/sandbikeengine_unique_speed_6" },
      { id: "sandbikeboost_unique_lessheat_6", name: "Night Rider Sandbike Boost Mk6", url: "https://dune.gaming.tools/items/sandbikeboost_unique_lessheat_6" },
      { id: "dewreaper_2h_unique_yieldincrease_06", name: "Omni Focused Dew Scythe", url: "https://dune.gaming.tools/items/dewreaper_2h_unique_yieldincrease_06" },
      { id: "stillsuit_unique_heatmitigation_06_mask", name: "Pardot's Hood", url: "https://dune.gaming.tools/items/stillsuit_unique_heatmitigation_06_mask" },
      { id: "shotgun_unique_blood_06", name: "Penetrator", url: "https://dune.gaming.tools/items/shotgun_unique_blood_06" },
      { id: "uniquescattergun5", name: "Perforator", url: "https://dune.gaming.tools/items/uniquescattergun5" },
      { id: "combat_neut_smugglerdeserterunique06_boots", name: "Pincushion Boots", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique06_boots" },
      { id: "combat_neut_smugglerdeserterunique06_top", name: "Pincushion Chestpiece", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique06_top" },
      { id: "combat_neut_smugglerdeserterunique06_gloves", name: "Pincushion Gauntlets", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique06_gloves" },
      { id: "combat_neut_smugglerdeserterunique06_helmet", name: "Pincushion Helmet", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique06_helmet" },
      { id: "combat_neut_smugglerdeserterunique06_bottom", name: "Pincushion Pants", url: "https://dune.gaming.tools/items/combat_neut_smugglerdeserterunique06_bottom" },
      { id: "lmg_unique_power_06", name: "Plasma Cannon", url: "https://dune.gaming.tools/items/lmg_unique_power_06" },
      { id: "fireballer_3", name: "Plastanium Pyrocket", url: "https://dune.gaming.tools/items/fireballer_3" },
      { id: "combat_heavy_unique_powerincrease_top_06", name: "Power Harness", url: "https://dune.gaming.tools/items/combat_heavy_unique_powerincrease_top_06" },
      { id: "buggyboost_unique_lessheat_6", name: "Rattler Boost Module Mk6", url: "https://dune.gaming.tools/items/buggyboost_unique_lessheat_6" },
      { id: "shotgun_unique_explosive_06", name: "Regis Burst Drillshot", url: "https://dune.gaming.tools/items/shotgun_unique_explosive_06" },
      { id: "heavypistol_unique_bleed_06", name: "Regis Disruptor Pistol", url: "https://dune.gaming.tools/items/heavypistol_unique_bleed_06" },
      { id: "longrifle_unique_largemag_06", name: "Regis Tripleshot Repeating Rifle", url: "https://dune.gaming.tools/items/longrifle_unique_largemag_06" },
      { id: "kindjal_unique_stamina_06", name: "Replica Pulse-knife", url: "https://dune.gaming.tools/items/kindjal_unique_stamina_06" },
      { id: "uniquesword_05", name: "Replica Pulse-sword", url: "https://dune.gaming.tools/items/uniquesword_05" },
      { id: "ornithoptertransportlocomotion_unique_speed_6", name: "Roc Carrier Wing", url: "https://dune.gaming.tools/items/ornithoptertransportlocomotion_unique_speed_6" },
      { id: "uniquear4", name: "Salusan Vengeance", url: "https://dune.gaming.tools/items/uniquear4" },
      { id: "uniquesmg3", name: "Sardaukar Intimidator", url: "https://dune.gaming.tools/items/uniquesmg3" },
      { id: "heavypistol_unique_headshot_06", name: "Seethe", url: "https://dune.gaming.tools/items/heavypistol_unique_headshot_06" },
      { id: "fullstabilizationbelt_unique_dmgreduction", name: "Sentinel Belt", url: "https://dune.gaming.tools/items/fullstabilizationbelt_unique_dmgreduction" },
      { id: "stillsuit_unique_highcapacity_06_top", name: "Shaddam's Bladder", url: "https://dune.gaming.tools/items/stillsuit_unique_highcapacity_06_top" },
      { id: "uniquescattergun_fire_06", name: "Shellburster", url: "https://dune.gaming.tools/items/uniquescattergun_fire_06" },
      { id: "uniquesda_doubleshot_06", name: "Shishakli's Bite", url: "https://dune.gaming.tools/items/uniquesda_doubleshot_06" },
      { id: "unique_sword_bleedyblocky_6", name: "Spike Hilt Sword", url: "https://dune.gaming.tools/items/unique_sword_bleedyblocky_6" },
      { id: "uniquerapier_power_06", name: "Static Needle", url: "https://dune.gaming.tools/items/uniquerapier_power_06" },
      { id: "ornithoptermediumboost_unique_lessheat_6", name: "Steady Assault Boost Module Mk6", url: "https://dune.gaming.tools/items/ornithoptermediumboost_unique_lessheat_6" },
      { id: "ornithoptertransportboost_unique_lessheat_06", name: "Steady Carrier Boost Module Mk6", url: "https://dune.gaming.tools/items/ornithoptertransportboost_unique_lessheat_06" },
      { id: "treadwheelboost_unique_lessheat_6", name: "Steady Treadwheel Boost Module Mk6", url: "https://dune.gaming.tools/items/treadwheelboost_unique_lessheat_6" },
      { id: "ornithopterlightboost_unique_lessheat_6", name: "Stormrider Boost Module Mk6", url: "https://dune.gaming.tools/items/ornithopterlightboost_unique_lessheat_6" },
      { id: "treadwheelengine_unique_speed_6", name: "Swift Treadwheel Engine Mk6", url: "https://dune.gaming.tools/items/treadwheelengine_unique_speed_6" },
      { id: "combat_light_unique_wormthreat_boots_06", name: "Tabr Softstep Boots", url: "https://dune.gaming.tools/items/combat_light_unique_wormthreat_boots_06" },
      { id: "radiation_suit_t6_unique_armored", name: "Tactical Radiation Suit", url: "https://dune.gaming.tools/items/radiation_suit_t6_unique_armored" },
      { id: "rocketlauncher_unique_homing_06", name: "The Ancient Way", url: "https://dune.gaming.tools/items/rocketlauncher_unique_homing_06" },
      { id: "bloodsack_unique_durable_06", name: "The Baron's Bloodbag", url: "https://dune.gaming.tools/items/bloodsack_unique_durable_06" },
      { id: "glidepartialstabilizationbelt_06", name: "The Emperor's Wings Mk6", url: "https://dune.gaming.tools/items/glidepartialstabilizationbelt_06" },
      { id: "combat_hark_medunique02_boots", name: "The Forge Boots", url: "https://dune.gaming.tools/items/combat_hark_medunique02_boots" },
      { id: "combat_hark_medunique02_top", name: "The Forge Chestpiece", url: "https://dune.gaming.tools/items/combat_hark_medunique02_top" },
      { id: "combat_hark_medunique02_gloves", name: "The Forge Gloves", url: "https://dune.gaming.tools/items/combat_hark_medunique02_gloves" },
      { id: "combat_hark_medunique02_helmet", name: "The Forge Helmet", url: "https://dune.gaming.tools/items/combat_hark_medunique02_helmet" },
      { id: "combat_hark_medunique02_bottom", name: "The Forge Pants", url: "https://dune.gaming.tools/items/combat_hark_medunique02_bottom" },
      { id: "sandcrawlerspicecontainer_unique_capacity_6", name: "Upgraded Regis Spice Container", url: "https://dune.gaming.tools/items/sandcrawlerspicecontainer_unique_capacity_6" },
      { id: "uniqueflamethrower_02", name: "Vaporizer", url: "https://dune.gaming.tools/items/uniqueflamethrower_02" },
      { id: "stillsuit_unique_efficient_06_boots", name: "Villari's Stillsuit Boots", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_06_boots" },
      { id: "stillsuit_unique_efficient_06_top", name: "Villari's Stillsuit Garment", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_06_top" },
      { id: "stillsuit_unique_efficient_06_gloves", name: "Villari's Stillsuit Gloves", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_06_gloves" },
      { id: "stillsuit_unique_efficient_06_mask", name: "Villari's Stillsuit Mask", url: "https://dune.gaming.tools/items/stillsuit_unique_efficient_06_mask" },
      { id: "sandcrawlerengine_unique_speed_06", name: "Walker Sandcrawler Engine Mk6", url: "https://dune.gaming.tools/items/sandcrawlerengine_unique_speed_06" },
      { id: "uniquesda6", name: "Way of the Misr", url: "https://dune.gaming.tools/items/uniquesda6" },
      { id: "combat_light_unique_scanning_helmet_06", name: "Wayfinder Helm", url: "https://dune.gaming.tools/items/combat_light_unique_scanning_helmet_06" },
      { id: "powerpack_unique_regen_06", name: "Young Sparky Mk6", url: "https://dune.gaming.tools/items/powerpack_unique_regen_06" },
      { id: "combat_light_unique_dewreap_gloves_06", name: "Yueh's Reaper Gloves", url: "https://dune.gaming.tools/items/combat_light_unique_dewreap_gloves_06" },
    ]
  },
  {
    tier: "Augmentations", tierNum: 7, color: "#7eb8f7",
    items: []
  },
];

const TOTAL = TIERS.reduce((sum, t) => sum + t.items.length, 0);

const IMG_META: Record<string, string> = {"combat_neut_smugglerdeserterunique01_boots":"t_ui_iconclothneutsmugdeserterunique01bootsr_d.webp","combat_neut_smugglerdeserterunique01_top":"t_ui_iconclothneutsmugdeserterunique01topr_d.webp","combat_neut_smugglerdeserterunique01_gloves":"t_ui_iconclothneutsmugdeserterunique01glovesr_d.webp","combat_neut_smugglerdeserterunique01_helmet":"t_ui_iconclothneutsmugdeserterunique01helmetr_d.webp","combat_neut_smugglerdeserterunique01_bottom":"t_ui_iconclothneutsmugdeserterunique01bottomr_d.webp","uniquear_burst_01":"t_ui_iconwpnuniquear_burst_01r_d.webp","highcapacityliterjon":"t_ui_iconconsumliterjonr_d.webp","stillsuit_unique_armored_01_boots":"t_ui_iconclothstillsuituniquearmored01bootsr_d.webp","stillsuit_unique_armored_01_top":"t_ui_iconclothstillsuituniquearmored01topr_d.webp","stillsuit_unique_armored_01_gloves":"t_ui_iconclothstillsuituniquearmored01glovesr_d.webp","stillsuit_unique_armored_01_mask":"t_ui_iconclothstillsuituniquearmored01maskr_d.webp","kindjal_unique_blood_01":"t_ui_iconwpnmeleekindjal_unique_blood_01r_d.webp","sandbikeengine_unique_speed_1":"t_ui_iconvehch1mgcenginer_d.webp","powerpack_unique_regen_01":"t_ui_iconwearchoampowerpack01r_d.webp","miningtool_1h_unique_01":"t_ui_icontoolminingtool_1h_unique_01r_d.webp","glidepartialstabilizationbelt":"t_ui_iconwearchoamsuspensorpartialreductionr_d.webp","uniquesda1":"t_ui_iconwpniconuniquesda1r_d.webp","dewreaper_unique_01":"t_ui_icontooldewreaper_unique_01r_d.webp","stillsuit_choam_unique_dashed02_top":"t_ui_iconclothstillsuituniquearmored02topr_d.webp","uniquear_burst_02":"t_ui_iconwpnuniquear_burst_02r_d.webp","highcapacityliterjon_02":"t_ui_iconconsumliterjonr_d.webp","combat_heavy_unique_powerefficient_gloves_02":"t_ui_iconclothheavyuniquepowerefficientgloves02r_d.webp","smg_unique_largemag_02":"t_ui_iconwpnsmg_unique_largemag_02r_d.webp","combat_neut_smugglerdeserterunique02_boots":"t_ui_iconclothneutsmugdeserterunique02bootsr_d.webp","combat_neut_smugglerdeserterunique02_gloves":"t_ui_iconclothneutsmugdeserterunique02glovesr_d.webp","combat_neut_smugglerdeserterunique02_top":"t_ui_iconclothneutsmugdeserterunique02topr_d.webp","combat_neut_smugglerdeserterunique02_bottom":"t_ui_iconclothneutsmugdeserterunique02bottomr_d.webp","combat_neut_smugglerdeserterunique02_helmet":"t_ui_iconclothneutsmugdeserterunique02helmetr_d.webp","stillsuit_unique_armored_02_boots":"t_ui_iconclothstillsuituniquearmored02bootsr_d.webp","stillsuit_unique_armored_02_top":"t_ui_iconclothstillsuituniquearmored02topr_d.webp","stillsuit_unique_armored_02_gloves":"t_ui_iconclothstillsuituniquearmored02glovesr_d.webp","stillsuit_unique_armored_02_mask":"t_ui_iconclothstillsuituniquearmored02maskr_d.webp","sandbikeengine_unique_speed_2":"t_ui_iconvehch1mgcenginer_d.webp","sandbikeboost_unique_lessheat_2":"t_ui_iconvehch1mgcboostr_d.webp","combat_neut_atreidesdeserterunique01_boots":"t_ui_iconclothneutatredeserterunique01bootsr_d.webp","combat_neut_atreidesdeserterunique01_top":"t_ui_iconclothneutatredeserterunique01topr_d.webp","combat_neut_atreidesdeserterunique01_gloves":"t_ui_iconclothneutatredeserterunique01glovesr_d.webp","combat_neut_atreidesdeserterunique01_helmet":"t_ui_iconclothneutatredeserterunique01helmetr_d.webp","combat_neut_atreidesdeserterunique01_bottom":"t_ui_iconclothneutatredeserterunique01bottomr_d.webp","powerpack_unique_regen_02":"t_ui_iconwearchoampowerpack01r_d.webp","miningtool_1h_unique_02":"t_ui_icontoolminingtool_1h_unique_02r_d.webp","uniquesword":"t_ui_iconwpnmeleeuniqueswordr_d.webp","bloodsack_unique_durable_02":"t_ui_iconconsumbloodsackr_d.webp","kindjal_unique_blood_02":"t_ui_iconwpnmeleekindjal_unique_blood_02r_d.webp","uniquescattergun1":"t_ui_iconwpnuniquescattergun1r_d.webp","combat_light_unique_wormthreat_boots_02":"t_ui_iconclothlightuniquewormthreatboots02r_d.webp","glidepartialstabilizationbelt_02":"t_ui_iconwearchoamsuspensorpartialreductionr_d.webp","uniquesda2":"t_ui_iconwpniconuniquesda2r_d.webp","heavypistol_unique_bleed_03":"t_ui_iconwpnheavypistol_unique_bleed_03r_d.webp","longrifle_unique_poison_03":"t_ui_iconwpnlongrifle_unique_poison_03r_d.webp","buggyinventory_unique_capacity_03":"t_ui_iconvehccbinventoryr_d.webp","buggyengine_unique_accelerate_03":"t_ui_iconvehccbenginer_d.webp","dewreaper_unique_02":"t_ui_icontooldewreaper_unique_02r_d.webp","miningtool_2h_unique_01":"t_ui_icontoolminingtool_2h_unique_01r_d.webp","staticcompactor_unique_compact_03":"t_ui_icontoolstaticcompactor_unique_compact_03r_d.webp","bodyfluidextractor_unique_water_03":"t_ui_icontoolbodyfluidextractor_unique_water_03r_d.webp","buggymining_unique_yieldincrease_03":"t_ui_iconvehccbmininglaserr_d.webp","bloodsack_unique_durable_03":"t_ui_iconconsumbloodsackr_d.webp","kindjal_unique_blood_03":"t_ui_iconwpnmeleekindjal_unique_blood_03r_d.webp","highcapacityliterjon_03":"t_ui_iconconsumliterjonr_d.webp","scanner_unique_body_03":"t_ui_icontoolscanner_unique_body_03r_d.webp","combat_neut_smugglerdeserterunique03_boots":"t_ui_iconclothneutsmugdeserterunique03bootsr_d.webp","combat_neut_smugglerdeserterunique03_gloves":"t_ui_iconclothneutsmugdeserterunique03glovesr_d.webp","combat_neut_smugglerdeserterunique03_top":"t_ui_iconclothneutsmugdeserterunique03topr_d.webp","combat_neut_smugglerdeserterunique03_helmet":"t_ui_iconclothneutsmugdeserterunique03helmetr_d.webp","combat_neut_smugglerdeserterunique03_bottom":"t_ui_iconclothneutsmugdeserterunique03bottomr_d.webp","combat_neut_atreidesdeserterunique02_boots":"t_ui_iconclothneutatredeserterunique02bootsr_d.webp","combat_neut_atreidesdeserterunique02_gloves":"t_ui_iconclothneutatredeserterunique02glovesr_d.webp","combat_neut_atreidesdeserterunique02_helmet":"t_ui_iconclothneutatredeserterunique02helmetr_d.webp","combat_neut_atreidesdeserterunique02_top":"t_ui_iconclothneutatredeserterunique02topr_d.webp","combat_neut_atreidesdeserterunique02_bottom":"t_ui_iconclothneutatredeserterunique02bottomr_d.webp","stillsuit_unique_armored_03_boots":"t_ui_iconclothstillsuituniquearmored03bootsr_d.webp","stillsuit_unique_armored_03_top":"t_ui_iconclothstillsuituniquearmored03topr_d.webp","stillsuit_unique_armored_03_gloves":"t_ui_iconclothstillsuituniquearmored03glovesr_d.webp","stillsuit_unique_armored_03_mask":"t_ui_iconclothstillsuituniquearmored03maskr_d.webp","sandbikeengine_unique_speed_3":"t_ui_iconvehch1mgcenginer_d.webp","sandbikeboost_unique_lessheat_3":"t_ui_iconvehch1mgcboostr_d.webp","powerpack_unique_regen_03":"t_ui_iconwearchoampowerpack01r_d.webp","buggyboost_unique_lessheat_3":"t_ui_iconvehccbboostr_d.webp","combat_light_unique_dewreap_gloves_03":"t_ui_iconclothlightuniquedewreapgloves03r_d.webp","combat_light_unique_reducesuspensor_top_03":"t_ui_iconclothlightuniquereducesuspensortop03r_d.webp","uniquescattergun2":"t_ui_iconwpnuniquescattergun2r_d.webp","uniquedirk":"t_ui_iconwpnmeleeuniquedirkr_d.webp","smg_unique_largemag_03":"t_ui_iconwpnsmg_unique_largemag_03r_d.webp","combat_heavy_unique_powerefficient_gloves_03":"t_ui_iconclothheavyuniquepowerefficientgloves03r_d.webp","kindjal_unique_stamina_03":"t_ui_iconwpnmeleekindjal_unique_stamina_03r_d.webp","uniquesword_02":"t_ui_iconwpnmeleeuniquesword_02r_d.webp","combat_light_unique_biomeheat_top_03":"t_ui_iconclothlightuniquebiomheattop03r_d.webp","stillsuit_choam_unique_dashed03_top":"t_ui_iconclothstillsuituniquearmored03topr_d.webp","combat_light_unique_wormthreat_boots_03":"t_ui_iconclothlightuniquewormthreatboots03r_d.webp","glidepartialstabilizationbelt_03":"t_ui_iconwearchoamsuspensorpartialreductionr_d.webp","uniquear1":"t_ui_iconwpnuniquear1r_d.webp","uniquesda3":"t_ui_iconwpniconuniquesda3r_d.webp","uniquear_burst_03":"t_ui_iconwpnuniquear_burst_03r_d.webp","uniquesmg1":"t_ui_iconwpnuniquesmg1r_d.webp","ornithopterlightlocomotion_unique_speed_4":"t_ui_iconvehcolwingsr_d.webp","buggyinventory_unique_capacity_04":"t_ui_iconvehccbinventoryr_d.webp","buggyengine_unique_accelerate_04":"t_ui_iconvehccbenginer_d.webp","dewreaper_unique_03":"t_ui_icontooldewreaper_unique_03r_d.webp","uniquethumper":"t_ui_iconplacchoamcompactthumper01r_d.webp","dewreaper_1h_unique_compact_04":"t_ui_icontooldewreaper_1h_unique_compact_04r_d.webp","staticcompactor_unique_compact_04":"t_ui_icontoolstaticcompactor_unique_compact_04r_d.webp","combat_light_unique_stamina_bottom_04":"t_ui_iconclothlightuniquestaminabottom04r_d.webp","uniquedirk_02":"t_ui_iconwpnmeleeuniquedirk_02r_d.webp","uniquescattergun3":"t_ui_iconwpnuniquescattergun3r_d.webp","lmg_unique_rapidfire_04":"t_ui_iconwpnlmg_unique_rapidfire_04r_d.webp","bodyfluidextractor_unique_water_04":"t_ui_icontoolbodyfluidextractor_unique_water_04r_d.webp","uniquescattergun_fire_04":"t_ui_iconwpnuniquescattergun_fire_04r_d.webp","buggymining_unique_yieldincrease_04":"t_ui_iconvehccbmininglaserr_d.webp","highcapacityliterjon_04":"t_ui_iconconsumliterjonr_d.webp","shotgun_unique_explosive_04":"t_ui_iconwpnshotgun_unique_explosive_04r_d.webp","heavypistol_unique_bleed_04":"t_ui_iconwpnheavypistol_unique_bleed_04r_d.webp","combat_light_unique_wormthreat_boots_04":"t_ui_iconclothlightuniquewormthreatboots04r_d.webp","combat_light_unique_dewreap_gloves_04":"t_ui_iconclothlightuniquedewreapgloves04r_d.webp","combat_light_unique_reducesuspensor_top_04":"t_ui_iconclothlightuniquereducesuspensortop04r_d.webp","smg_unique_largemag_04":"t_ui_iconwpnsmg_unique_largemag_04r_d.webp","longrifle_unique_poison_04":"t_ui_iconwpnlongrifle_unique_poison_04r_d.webp","stillsuit_unique_efficient_04_boots":"t_ui_iconclothstillsuituniqueefficient04bootsr_d.webp","stillsuit_unique_efficient_04_top":"t_ui_iconclothstillsuituniqueefficient04topr_d.webp","stillsuit_unique_efficient_04_gloves":"t_ui_iconclothstillsuituniqueefficient04glovesr_d.webp","stillsuit_unique_efficient_04_mask":"t_ui_iconclothstillsuituniqueefficient04maskr_d.webp","combat_light_unique_biomeheat_top_04":"t_ui_iconclothlightuniquebiomheattop04r_d.webp","sandbikeengine_unique_speed_4":"t_ui_iconvehch1mgcenginer_d.webp","sandbikeboost_unique_lessheat_4":"t_ui_iconvehch1mgcboostr_d.webp","powerpack_unique_regen_04":"t_ui_iconwearchoampowerpack01r_d.webp","uniquear2":"t_ui_iconwpnuniquear2r_d.webp","uniquerapier":"t_ui_iconwpnmeleeuniquerapierr_d.webp","combat_heavy_unique_powerefficient_gloves_04":"t_ui_iconclothheavyuniquepowerefficientgloves04r_d.webp","combat_neut_smugglerdeserterunique04_boots":"t_ui_iconclothneutsmugdeserterunique04bootsr_d.webp","combat_neut_smugglerdeserterunique04_gloves":"t_ui_iconclothneutsmugdeserterunique04glovesr_d.webp","combat_neut_smugglerdeserterunique04_helmet":"t_ui_iconclothneutsmugdeserterunique04helmetr_d.webp","combat_neut_smugglerdeserterunique04_top":"t_ui_iconclothneutsmugdeserterunique04topr_d.webp","combat_neut_smugglerdeserterunique04_bottom":"t_ui_iconclothneutsmugdeserterunique04bottomr_d.webp","buggyboost_unique_lessheat_4":"t_ui_iconvehccbboostr_d.webp","stillsuit_choam_unique_dashed04_top":"t_ui_iconclothstillsuituniquearmored04topr_d.webp","miningtool_2h_unique_02":"t_ui_icontoolminingtool_2h_unique_05r_d.webp","combat_neut_atreidesdeserterunique03_boots":"t_ui_iconclothneutatredeserterunique03bootsr_d.webp","combat_neut_atreidesdeserterunique03_gloves":"t_ui_iconclothneutatredeserterunique03glovesr_d.webp","combat_neut_atreidesdeserterunique03_helmet":"t_ui_iconclothneutatredeserterunique03helmetr_d.webp","combat_neut_atreidesdeserterunique03_top":"t_ui_iconclothneutatredeserterunique03topr_d.webp","combat_neut_atreidesdeserterunique03_bottom":"t_ui_iconclothneutatredeserterunique03bottomr_d.webp","stillsuit_unique_heatmitigation_04_mask":"t_ui_iconclothstillsuituniquehighmitigation04maskr_d.webp","kindjal_unique_blood_04":"t_ui_iconwpnmeleekindjal_unique_blood_04r_d.webp","uniquesda_doubleshot_04":"t_ui_iconwpnuniquesda_doubleshot_04r_d.webp","stillsuit_unique_armored_04_boots":"t_ui_iconclothstillsuituniquearmored04bootsr_d.webp","stillsuit_unique_armored_04_top":"t_ui_iconclothstillsuituniquearmored04topr_d.webp","stillsuit_unique_armored_04_gloves":"t_ui_iconclothstillsuituniquearmored04glovesr_d.webp","stillsuit_unique_armored_04_mask":"t_ui_iconclothstillsuituniquearmored04maskr_d.webp","bloodsack_unique_durable_04":"t_ui_iconconsumbloodsackr_d.webp","kindjal_unique_stamina_04":"t_ui_iconwpnmeleekindjal_unique_stamina_04r_d.webp","uniquesword_03":"t_ui_iconwpnmeleeuniquesword_03r_d.webp","uniquear_burst_04":"t_ui_iconwpnuniquear_burst_04r_d.webp","treadwheelboost_unique_lessheat_4":"t_ui_iconvehoetreadwheelboostr_d.webp","ornithopterlightboost_unique_lessheat_4":"t_ui_iconvehcolboostr_d.webp","treadwheelengine_unique_speed_4":"t_ui_iconvehoetreadwheelenginer_d.webp","unique_sword_bleedyblocky_4":"t_ui_iconmtxwpnmeleeswordartdecor_d.webp","glidepartialstabilizationbelt_04":"t_ui_iconwearchoamsuspensorpartialreductionr_d.webp","uniquesda4":"t_ui_iconwpniconuniquesda4r_d.webp","combat_neut_atreidesdeserterunique04_boots":"t_ui_iconclothneutatredeserterunique04bootsr_d.webp","combat_neut_atreidesdeserterunique04_top":"t_ui_iconclothneutatredeserterunique04topr_d.webp","combat_neut_atreidesdeserterunique04_gloves":"t_ui_iconclothneutatredeserterunique04glovesr_d.webp","combat_neut_atreidesdeserterunique04_helmet":"t_ui_iconclothneutatredeserterunique04helmetr_d.webp","combat_neut_atreidesdeserterunique04_bottom":"t_ui_iconclothneutatredeserterunique04bottomr_d.webp","shotgun_unique_explosive_05":"t_ui_iconwpnshotgun_unique_explosive_05r_d.webp","heavypistol_unique_bleed_05":"t_ui_iconwpnheavypistol_unique_bleed_05r_d.webp","combat_light_unique_dewreap_gloves_05":"t_ui_iconclothlightuniquedewreapgloves05r_d.webp","combat_light_unique_reducesuspensor_top_05":"t_ui_iconclothlightuniquereducesuspensortop05r_d.webp","ornithopterlightlocomotion_unique_speed_5":"t_ui_iconvehcolwingsr_d.webp","choamlg1":"t_ui_iconwpnchoamlg1r_d.webp","stillsuit_unique_efficient_05_boots":"t_ui_iconclothstillsuituniqueefficient05bootsr_d.webp","stillsuit_unique_efficient_05_top":"t_ui_iconclothstillsuituniqueefficient05topr_d.webp","stillsuit_unique_efficient_05_gloves":"t_ui_iconclothstillsuituniqueefficient05glovesr_d.webp","stillsuit_unique_efficient_05_mask":"t_ui_iconclothstillsuituniqueefficient05maskr_d.webp","benegesserit_armorset":"t_ui_iconclothbenegtopmalet3r_d.webp","buggyinventory_unique_capacity_05":"t_ui_iconvehccbinventoryr_d.webp","unique_sword_bleedyblocky_5":"t_ui_iconwpnmeleeuniquesword_02r_d.webp","buggyengine_unique_accelerate_05":"t_ui_iconvehccbenginer_d.webp","dewreaper_unique_04":"t_ui_icontooldewreaper_unique_04r_d.webp","combat_neut_smugglerdeserterunique05_boots":"t_ui_iconclothneutsmugdeserterunique05bootsr_d.webp","combat_neut_smugglerdeserterunique05_top":"t_ui_iconclothneutsmugdeserterunique05topr_d.webp","combat_neut_smugglerdeserterunique05_gloves":"t_ui_iconclothneutsmugdeserterunique05glovesr_d.webp","combat_neut_smugglerdeserterunique05_helmet":"t_ui_iconclothneutsmugdeserterunique05helmetr_d.webp","combat_neut_smugglerdeserterunique05_bottom":"t_ui_iconclothneutsmugdeserterunique05bottomr_d.webp","dewreaper_1h_unique_compact_05":"t_ui_icontooldewreaper_1h_unique_compact_05r_d.webp","staticcompactor_unique_compact_05":"t_ui_icontoolstaticcompactor_unique_compact_05r_d.webp","heavypistol_unique_headshot_05":"t_ui_iconwpnheavypistol_unique_headshot_05r_d.webp","stilltent_unique_01":"t_ui_iconplacchoamstilltentr_d.webp","stillsuit_choam_unique_dashed05_top":"t_ui_iconclothstillsuituniquearmored05topr_d.webp","lmg_unique_rapidfire_05":"t_ui_iconwpnlmg_unique_rapidfire_05r_d.webp","bodyfluidextractor_unique_water_05":"t_ui_icontoolbodyfluidextractor_unique_water_05r_d.webp","longrifle_unique_largemag_05":"t_ui_iconwpnlongrifle_unique_largemag_05r_d.webp","buggymining_unique_yieldincrease_05":"t_ui_iconvehccbmininglaserr_d.webp","dewreaper_2h_unique_yieldincrease_05":"t_ui_icontooldewreaper_2h_unique_yieldincrease_05r_d.webp","highcapacityliterjon_05":"t_ui_iconconsumliterjonr_d.webp","ornithoptermediumlocomotion_unique_strafe_5":"t_ui_iconvehcmowingsr_d.webp","bodyfluidextractor_unique_poison_05":"t_ui_icontoolbodyfluidextractor_unique_poison_05r_d.webp","kindjal_unique_stamina_05":"t_ui_iconwpnmeleekindjal_unique_stamina_05r_d.webp","uniquesword_04":"t_ui_iconwpnmeleeuniquesword_04r_d.webp","uniquerapier_02":"t_ui_iconwpnmeleeuniquerapier_02r_d.webp","scanner_efficient_1":"t_ui_icontool1hsmughandheldscannerr_d.webp","bloodsack_unique_durable_05":"t_ui_iconconsumbloodsackr_d.webp","combat_heavy_unique_reinforced_boots_05":"t_ui_iconclothheavyuniquereinforcedboots05r_d.webp","combat_heavy_unique_reinforced_top_05":"t_ui_iconclothheavyuniquereinforcedtop05r_d.webp","combat_heavy_unique_reinforced_gloves_05":"t_ui_iconclothheavyuniquereinforcedgloves05r_d.webp","combat_heavy_unique_reinforced_helmet_05":"t_ui_iconclothheavyuniquereinforcedhelmet05r_d.webp","combat_heavy_unique_reinforced_bottom_05":"t_ui_iconclothheavyuniquereinforcedbottom05r_d.webp","uniquear_burst_05":"t_ui_iconwpnuniquear_burst_05r_d.webp","mentat_lightarmorset":"t_ui_iconclothmentattopmalet3r_d.webp","sandbikeengine_unique_speed_5":"t_ui_iconvehch1mgcenginer_d.webp","uniquedirk_03":"t_ui_iconwpnmeleeuniquedirk_03r_d.webp","sandbikeboost_unique_lessheat_5":"t_ui_iconvehch1mgcboostr_d.webp","kindjal_unique_blood_05":"t_ui_iconwpnmeleekindjal_unique_blood_05r_d.webp","uniquesmg2":"t_ui_iconwpnuniquesmg2r_d.webp","planetologist_lightarmorset":"t_ui_iconclothplanetologisttopmalet3r_d.webp","buggyboost_unique_lessheat_5":"t_ui_iconvehccbboostr_d.webp","smg_unique_largemag_05":"t_ui_iconwpnsmg_unique_largemag_05r_d.webp","stillsuit_unique_armored_05_boots":"t_ui_iconclothstillsuituniquearmored05bootsr_d.webp","stillsuit_unique_armored_05_top":"t_ui_iconclothstillsuituniquearmored05topr_d.webp","stillsuit_unique_armored_05_gloves":"t_ui_iconclothstillsuituniquearmored05glovesr_d.webp","stillsuit_unique_armored_05_mask":"t_ui_iconclothstillsuituniquearmored05maskr_d.webp","flamethrower_prototype":"t_ui_iconwpnflamethrower_prototyper_d.webp","uniquear3":"t_ui_iconwpnuniquear3r_d.webp","stillsuit_unique_heatmitigation_05_mask":"t_ui_iconclothstillsuituniquehighmitigation05maskr_d.webp","uniqueflamethrower":"t_ui_iconwpnuniqueflamethrowerr_d.webp","uniquescattergun_fire_05":"t_ui_iconwpnuniquescattergun_fire_05r_d.webp","combat_light_unique_biomeheat_top_05":"t_ui_iconclothlightuniquebiomheattop05r_d.webp","combat_heavy_unique_powerefficient_gloves_05":"t_ui_iconclothheavyuniquepowerefficientgloves05r_d.webp","ornithoptermediumboost_unique_lessheat_5":"t_ui_iconvehcmoboostr_d.webp","treadwheelboost_unique_lessheat_5":"t_ui_iconvehoetreadwheelboostr_d.webp","combat_light_unique_stamina_bottom_05":"t_ui_iconclothlightuniquestaminabottom05r_d.webp","ornithopterlightboost_unique_lessheat_5":"t_ui_iconvehcolboostr_d.webp","treadwheelengine_unique_speed_5":"t_ui_iconvehoetreadwheelenginer_d.webp","swordmaster_heavyarmorset":"t_ui_iconclothswordmastertopmalet3r_d.webp","combat_hark_medunique01_boots":"t_ui_iconclothharkmedunique01bootsr_d.webp","combat_hark_medunique01_top":"t_ui_iconclothharkmedunique01topr_d.webp","combat_hark_medunique01_gloves":"t_ui_iconclothharkmedunique01glovesr_d.webp","combat_hark_medunique01_helmet":"t_ui_iconclothharkmedunique01helmetr_d.webp","uniquescattergun4":"t_ui_iconwpnuniquescattergun4r_d.webp","combat_hark_medunique01_bottom":"t_ui_iconclothharkmedunique01bottomr_d.webp","uniquesda_doubleshot_05":"t_ui_iconwpnuniquesda_doubleshot_05r_d.webp","miningtool_2h_unique_03":"t_ui_icontoolminingtool_2h_unique_03r_d.webp","combat_light_unique_wormthreat_boots_05":"t_ui_iconclothlightuniquewormthreatboots05r_d.webp","glidepartialstabilizationbelt_05":"t_ui_iconwearchoamsuspensorpartialreductionr_d.webp","longrifle_unique_poison_05":"t_ui_iconwpnlongrifle_unique_poison_05r_d.webp","trooper_heavyarmorset":"t_ui_iconclothtroopertopmalet3r_d.webp","uniquesda5":"t_ui_iconwpniconuniquesda5r_d.webp","combat_light_unique_scanning_helmet_05":"t_ui_iconclothlightuniquescanninghelmet05r_d.webp","powerpack_unique_regen_05":"t_ui_iconwearchoampowerpack01r_d.webp","smg_unique_largemag_06":"t_ui_iconwpnsmg_unique_largemag_06r_d.webp","powerpack_unique_capacity_06":"t_ui_iconwearchoampowerpack01r_d.webp","holtzmanshieldactivedrain_unique_01":"t_ui_iconwearchoamshield01r_d.webp","ornithopterlightlocomotion_unique_speed_6":"t_ui_iconvehcolwingsr_d.webp","shotgun_unique_largemag_06":"t_ui_iconwpn2hsmugshotgun01_t6r_d.webp","lmg_unique_rapidfire_06":"t_ui_iconwpnlmg_unique_rapidfire_06r_d.webp","buggyinventory_unique_capacity_06":"t_ui_iconvehccbinventoryr_d.webp","choamlg2":"t_ui_iconwpnchoamlg2r_d.webp","buggyengine_unique_accelerate_06":"t_ui_iconvehccbenginer_d.webp","combat_heavy_unique_reinforced_boots_06":"t_ui_iconclothheavyuniquereinforcedboots06r_d.webp","combat_heavy_unique_reinforced_top_06":"t_ui_iconclothheavyuniquereinforcedtop06r_d.webp","combat_heavy_unique_reinforced_gloves_06":"t_ui_iconclothheavyuniquereinforcedgloves06r_d.webp","combat_heavy_unique_reinforced_helmet_06":"t_ui_iconclothheavyuniquereinforcedhelmet06r_d.webp","combat_heavy_unique_reinforced_bottom_06":"t_ui_iconclothheavyuniquereinforcedbottom06r_d.webp","dewreaper_unique_05":"t_ui_icontooldewreaper_unique_05r_d.webp","uniquedualblades_6":"t_ui_iconwpnmeleeharkdualdagger01_sandf01r_d.webp","uniquedirk_04":"t_ui_iconwpnmeleeuniquedirk_04r_d.webp","combat_heavy_unique_powerefficient_gloves_06":"t_ui_iconclothheavyuniquepowerefficientgloves06r_d.webp","dewreaper_1h_unique_compact_06":"t_ui_icontooldewreaper_1h_unique_compact_06r_d.webp","staticcompactor_unique_compact_06":"t_ui_icontoolstaticcompactor_unique_compact_06r_d.webp","stillsuit_choam_unique_dashed06_top":"t_ui_iconclothstillsuituniquearmored06topr_d.webp","sandcrawlerlocomotion_unique_wormthreat_06":"t_ui_iconvehcigctreadsr_d.webp","combat_light_unique_biomeheat_top_06":"t_ui_iconclothlightuniquebiomheattop06r_d.webp","longrifle_unique_poison_06":"t_ui_iconwpnlongrifle_unique_poison_06r_d.webp","fullsuspensorbelt_unique_durability":"t_ui_iconwearchoamsuspensorfullreductionr_d.webp","combat_neut_atreidesdeserterunique05_boots":"t_ui_iconclothneutatredeserterunique05bootsr_d.webp","combat_neut_atreidesdeserterunique05_top":"t_ui_iconclothneutatredeserterunique05topr_d.webp","combat_neut_atreidesdeserterunique05_gloves":"t_ui_iconclothneutatredeserterunique05glovesr_d.webp","combat_neut_atreidesdeserterunique05_helmet":"t_ui_iconclothneutatredeserterunique05helmetr_d.webp","combat_neut_atreidesdeserterunique05_bottom":"t_ui_iconclothneutatredeserterunique05bottomr_d.webp","uniquear6_electric":"t_ui_iconwpnuniquear_burst_06r_d.webp","consumable_buff_poisonstackincrease":"t_ui_iconconsumpoisonresistancepillr_d.webp","kindjal_unique_blood_06":"t_ui_iconwpnmeleekindjal_unique_blood_06r_d.webp","bodyfluidextractor_unique_water_06":"t_ui_icontoolbodyfluidextractor_unique_water_06r_d.webp","buggymining_unique_yieldincrease_06":"t_ui_iconvehccbmininglaserr_d.webp","flamethrower_prototype_2":"t_ui_iconwpnflamethrower_prototype_2r_d.webp","highcapacityliterjon_06":"t_ui_iconconsumliterjont6r_d.webp","uniquerapier_03":"t_ui_iconwpnmeleeuniquerapier_03r_d.webp","combat_light_unique_climbing_gloves_06":"t_ui_iconclothlightuniqueclimbinggloves06r_d.webp","ornithoptermediumlocomotion_unique_strafe_6":"t_ui_iconvehcmowingsr_d.webp","combat_light_unique_reducesuspensor_top_06":"t_ui_iconclothlightuniquereducesuspensortop06r_d.webp","stillsuit_unique_armored_06_boots":"t_ui_iconclothstillsuituniquearmored06bootsr_d.webp","stillsuit_unique_armored_06_top":"t_ui_iconclothstillsuituniquearmored06topr_d.webp","stillsuit_unique_armored_06_gloves":"t_ui_iconclothstillsuituniquearmored06glovesr_d.webp","stillsuit_unique_armored_06_mask":"t_ui_iconclothstillsuituniquearmored06maskr_d.webp","bodyfluidextractor_unique_poison_06":"t_ui_icontoolbodyfluidextractor_unique_poison_06r_d.webp","uniquear_burst_06":"t_ui_iconwpnuniquear_burst_06r_d.webp","combat_light_unique_stamina_bottom_06":"t_ui_iconclothlightuniquestaminabottom06r_d.webp","miningtool_2h_unique_04":"t_ui_icontoolminingtool_2h_unique_04r_d.webp","sandbikeengine_unique_speed_6":"t_ui_iconvehch1mgcenginer_d.webp","sandbikeboost_unique_lessheat_6":"t_ui_iconvehch1mgcboostr_d.webp","dewreaper_2h_unique_yieldincrease_06":"t_ui_icontooldewreaper_2h_unique_yieldincrease_06r_d.webp","stillsuit_unique_heatmitigation_06_mask":"t_ui_iconclothstillsuituniquehighmitigation06maskr_d.webp","shotgun_unique_blood_06":"t_ui_iconwpnshotgun_unique_blood_06r_d.webp","uniquescattergun5":"t_ui_iconwpnuniquescattergun5r_d.webp","combat_neut_smugglerdeserterunique06_boots":"t_ui_iconclothneutsmugdeserterunique06bootsr_d.webp","combat_neut_smugglerdeserterunique06_top":"t_ui_iconclothneutsmugdeserterunique06topr_d.webp","combat_neut_smugglerdeserterunique06_gloves":"t_ui_iconclothneutsmugdeserterunique06glovesr_d.webp","combat_neut_smugglerdeserterunique06_helmet":"t_ui_iconclothneutsmugdeserterunique06helmetr_d.webp","combat_neut_smugglerdeserterunique06_bottom":"t_ui_iconclothneutsmugdeserterunique06bottomr_d.webp","lmg_unique_power_06":"t_ui_iconwpnlmg_unique_power_06r_d.webp","fireballer_3":"t_ui_iconwpnchoamfireballer01_t5r_d.webp","combat_heavy_unique_powerincrease_top_06":"t_ui_iconclothheavyuniquepowerincreasetop06r_d.webp","buggyboost_unique_lessheat_6":"t_ui_iconvehccbboostr_d.webp","shotgun_unique_explosive_06":"t_ui_iconwpnshotgun_unique_explosive_06r_d.webp","heavypistol_unique_bleed_06":"t_ui_iconwpnheavypistol_unique_bleed_06r_d.webp","longrifle_unique_largemag_06":"t_ui_iconwpnlongrifle_unique_largemag_06r2_d.webp","kindjal_unique_stamina_06":"t_ui_iconwpnmeleekindjal_unique_stamina_06r_d.webp","uniquesword_05":"t_ui_iconwpnmeleeuniquesword_05r_d.webp","ornithoptertransportlocomotion_unique_speed_6":"t_ui_iconvehctolocomotionr_d.webp","uniquear4":"t_ui_iconwpnuniquear4r_d.webp","uniquesmg3":"t_ui_iconwpnuniquesmg3r_d.webp","heavypistol_unique_headshot_06":"t_ui_iconwpnheavypistol_unique_headshot_06r_d.webp","fullstabilizationbelt_unique_dmgreduction":"t_ui_iconwearchoamsuspensorfullstabilizationr_d.webp","stillsuit_unique_highcapacity_06_top":"t_ui_iconclothstillsuituniquehighcapacity06topr_d.webp","uniquescattergun_fire_06":"t_ui_iconwpnuniquescattergun_fire_06r_d.webp","uniquesda_doubleshot_06":"t_ui_iconwpnuniquesda_doubleshot_06r_d.webp","unique_sword_bleedyblocky_6":"t_ui_iconwpnmeleeuniquesword_03r_d.webp","uniquerapier_power_06":"t_ui_iconwpnmeleeuniquerapier_power_06r_d.webp","ornithoptermediumboost_unique_lessheat_6":"t_ui_iconvehcmoboostr_d.webp","ornithoptertransportboost_unique_lessheat_06":"t_ui_iconvehctothrusterr_d.webp","treadwheelboost_unique_lessheat_6":"t_ui_iconvehoetreadwheelboostr_d.webp","ornithopterlightboost_unique_lessheat_6":"t_ui_iconvehcolboostr_d.webp","treadwheelengine_unique_speed_6":"t_ui_iconvehoetreadwheelenginer_d.webp","combat_light_unique_wormthreat_boots_06":"t_ui_iconclothlightuniquewormthreatboots06r_d.webp","radiation_suit_t6_unique_armored":"t_ui_iconcharclothingsmugradiationsuitt6uniquearmoredr_d.webp","rocketlauncher_unique_homing_06":"t_ui_iconwpnrocketlauncher_unique_homing_06r_d.webp","bloodsack_unique_durable_06":"t_ui_iconconsumplastaniumbloodsackr_d.webp","glidepartialstabilizationbelt_06":"t_ui_iconwearchoamsuspensorpartialreductionr_d.webp","combat_hark_medunique02_boots":"t_ui_iconclothharkmedunique02bootsr_d.webp","combat_hark_medunique02_top":"t_ui_iconclothharkmedunique02topr_d.webp","combat_hark_medunique02_gloves":"t_ui_iconclothharkmedunique02glovesr_d.webp","combat_hark_medunique02_helmet":"t_ui_iconclothharkmedunique02helmetr_d.webp","combat_hark_medunique02_bottom":"t_ui_iconclothharkmedunique02bottomr_d.webp","sandcrawlerspicecontainer_unique_capacity_6":"t_ui_iconvehcigcylinderr_d.webp","uniqueflamethrower_02":"t_ui_iconwpnuniqueflamethrower_02r_d.webp","stillsuit_unique_efficient_06_boots":"t_ui_iconclothstillsuituniqueefficient06bootsr_d.webp","stillsuit_unique_efficient_06_top":"t_ui_iconclothstillsuituniqueefficient06topr_d.webp","stillsuit_unique_efficient_06_gloves":"t_ui_iconclothstillsuituniqueefficient06glovesr_d.webp","stillsuit_unique_efficient_06_mask":"t_ui_iconclothstillsuituniqueefficient06maskr_d.webp","sandcrawlerengine_unique_speed_06":"t_ui_iconvehcigenginer_d.webp","uniquesda6":"t_ui_iconwpniconuniquesda6r_d.webp","combat_light_unique_scanning_helmet_06":"t_ui_iconclothlightuniquescanninghelmet06r_d.webp","powerpack_unique_regen_06":"t_ui_iconwearchoampowerpack01r_d.webp","combat_light_unique_dewreap_gloves_06":"t_ui_iconclothlightuniquedewreapgloves06r_d.webp"};
const IMG_BASE = "/icons/";

// ─── AUTH HELPERS ─────────────────────────────────────────────────────────────
const SESSION_KEY = 'dune_session';

function getSession(): string | null { return localStorage.getItem(SESSION_KEY); }
function setSession(u: string) { localStorage.setItem(SESSION_KEY, u); }
function clearSession() { localStorage.removeItem(SESSION_KEY); }

// ─── AUTH SCREEN ──────────────────────────────────────────────────────────────
function AuthScreen({ onLogin }: { onLogin: (username: string) => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setError('');
    const u = username.trim().toLowerCase();
    if (!u || !password) { setError('Name und Passwort eingeben.'); return; }
    if (u.length < 2) { setError('Name mind. 2 Zeichen.'); return; }
    if (mode === 'register') {
      if (password.length < 4) { setError('Passwort mind. 4 Zeichen.'); return; }
      if (password !== password2) { setError('Passwörter stimmen nicht überein.'); return; }
    }

    setLoading(true);
    try {
      const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: u, password }),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error ?? 'Fehler beim Anmelden.');
        setLoading(false);
        return;
      }
      setSession(u);
      onLogin(u);
    } catch {
      setError('Netzwerkfehler. Bitte erneut versuchen.');
    }
    setLoading(false);
  };

  const handleKey = (e: React.KeyboardEvent) => { if (e.key === 'Enter') submit(); };

  return (
    <div style={{ minHeight: '100vh', background: '#0a0a0a', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'Courier New', monospace" }}>
      <div style={{ width: 320, background: 'rgba(14,14,18,0.98)', border: '1px solid rgba(232,200,122,0.3)', borderRadius: 6, padding: '36px 28px', boxShadow: '0 0 60px rgba(0,0,0,0.9)' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{ fontSize: 10, letterSpacing: '0.3em', color: 'rgba(232,200,122,0.45)', textTransform: 'uppercase', marginBottom: 4 }}>Dune Awakening</div>
          <div style={{ fontSize: 15, letterSpacing: '0.18em', color: '#e8c87a', textTransform: 'uppercase', fontWeight: 'bold' }}>Unique Tracker</div>
        </div>
        <div style={{ display: 'flex', marginBottom: 20, border: '1px solid rgba(232,200,122,0.2)', borderRadius: 4, overflow: 'hidden' }}>
          {(['login', 'register'] as const).map(m => (
            <button key={m} onClick={() => { setMode(m); setError(''); }} style={{ flex: 1, padding: '7px 0', fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase', cursor: 'pointer', border: 'none', background: mode === m ? 'rgba(232,200,122,0.13)' : 'transparent', color: mode === m ? '#e8c87a' : 'rgba(180,180,180,0.4)', borderRight: m === 'login' ? '1px solid rgba(232,200,122,0.2)' : 'none' }}>
              {m === 'login' ? 'Anmelden' : 'Registrieren'}
            </button>
          ))}
        </div>
        {[
          { label: 'Dein Name', value: username, set: setUsername, type: 'text' },
          { label: 'Passwort', value: password, set: setPassword, type: 'password' },
          ...(mode === 'register' ? [{ label: 'Passwort wiederholen', value: password2, set: setPassword2, type: 'password' }] : []),
        ].map(({ label, value, set, type }) => (
          <div key={label} style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 9, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(232,200,122,0.55)', marginBottom: 5 }}>{label}</div>
            <input type={type} value={value} onChange={e => set(e.target.value)} onKeyDown={handleKey}
              style={{ width: '100%', boxSizing: 'border-box', background: 'rgba(20,20,26,0.9)', border: '1px solid rgba(232,200,122,0.2)', borderRadius: 3, padding: '8px 10px', color: '#d0d0e0', fontFamily: "'Courier New', monospace", fontSize: 12, outline: 'none' }} />
          </div>
        ))}
        {error && <div style={{ fontSize: 10, color: '#f87171', marginBottom: 12, textAlign: 'center' }}>{error}</div>}
        <button onClick={submit} disabled={loading}
          style={{ width: '100%', padding: '10px 0', marginTop: 4, background: 'rgba(232,200,122,0.1)', border: '1px solid rgba(232,200,122,0.4)', borderRadius: 3, color: '#e8c87a', fontFamily: "'Courier New', monospace", fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', cursor: 'pointer', opacity: loading ? 0.5 : 1 }}>
          {loading ? '...' : mode === 'login' ? 'Einloggen' : 'Account erstellen'}
        </button>
      </div>
    </div>
  );
}

interface Item {
  id: string;
  name: string;
  url: string;
}

interface TierData {
  tier: string;
  tierNum: number;
  color: string;
  items: Item[];
}

function truncateName(name: string): string {
  const words = name.split(' ');
  if (words.length <= 3) return name;
  return words.slice(0, 3).join(' ') + '…';
}

function ItemSlot({ item, collected, onToggle }: { item: Item; collected: boolean; onToggle: (id: string) => void }) {
  const [hovered, setHovered] = useState(false);
  const imgFile = IMG_META[item.id];
  const imgSrc = imgFile ? IMG_BASE + imgFile : null;

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    window.open(item.url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      className="relative select-none cursor-pointer"
      style={{ width: 88, height: 88 }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={() => onToggle(item.id)}
      onContextMenu={handleContextMenu}
    >
      <div
        className="w-full h-full rounded flex flex-col items-center justify-center overflow-hidden transition-all duration-200"
        style={{
          background: collected ? 'rgba(15,30,15,0.9)' : 'rgba(18,18,22,0.92)',
          border: `1px solid ${collected ? 'rgba(34,197,94,0.35)' : hovered ? 'rgba(255,255,255,0.16)' : 'rgba(255,255,255,0.07)'}`,
          filter: collected ? 'grayscale(55%) brightness(0.6)' : 'none',
          boxShadow: hovered && !collected ? '0 0 0 1px rgba(232,200,122,0.15) inset' : 'none',
        }}
      >
        {imgSrc ? (
          <img
            src={imgSrc}
            alt={item.name}
            style={{ width: 62, height: 62, objectFit: 'contain', imageRendering: 'pixelated' }}
          />
        ) : (
          <span
            style={{
              fontFamily: "'Courier New', Courier, monospace",
              fontSize: 9,
              color: collected ? 'rgba(160,160,160,0.65)' : 'rgba(215,215,225,0.88)',
              textAlign: 'center',
              padding: '0 6px',
              lineHeight: 1.35,
              wordBreak: 'break-word',
              display: '-webkit-box',
              WebkitLineClamp: 4,
              WebkitBoxOrient: 'vertical',
              overflow: 'hidden',
            }}
          >
            {truncateName(item.name)}
          </span>
        )}
      </div>

      {collected && (
        <div className="absolute inset-0 flex items-center justify-center rounded pointer-events-none">
          <span style={{ fontSize: 26, color: '#22c55e', textShadow: '0 0 10px rgba(34,197,94,0.7)', lineHeight: 1 }}>
            ✓
          </span>
        </div>
      )}

      {hovered && (
        <button
          className="absolute top-1 right-1 flex items-center justify-center rounded"
          style={{
            width: 18, height: 18,
            background: 'rgba(0,0,0,0.8)',
            border: '1px solid rgba(232,200,122,0.35)',
            fontSize: 10,
            cursor: 'pointer',
            zIndex: 10,
            color: '#e8c87a',
            lineHeight: 1,
          }}
          onClick={(e) => { e.stopPropagation(); window.open(item.url, '_blank', 'noopener,noreferrer'); }}
          title="Open item page"
        >
          🔗
        </button>
      )}

      {hovered && (
        <div
          className="absolute z-50 pointer-events-none"
          style={{
            bottom: 'calc(100% + 6px)',
            left: '50%',
            transform: 'translateX(-50%)',
            background: 'rgba(8,8,10,0.98)',
            border: '1px solid rgba(232,200,122,0.35)',
            borderRadius: 4,
            padding: '4px 10px',
            whiteSpace: 'nowrap',
            fontFamily: "'Courier New', Courier, monospace",
            fontSize: 11,
            color: '#e8c87a',
            boxShadow: '0 4px 16px rgba(0,0,0,0.7)',
          }}
        >
          {item.name}
        </div>
      )}
    </div>
  );
}

function TierSection({
  tierData,
  collected,
  onToggle,
  forceExpanded,
}: {
  tierData: TierData;
  collected: Set<string>;
  onToggle: (id: string) => void;
  forceExpanded: boolean;
}) {
  const [expanded, setExpanded] = useState(true);
  const isPlaceholder = tierData.items.length === 0;
  const tierCollected = tierData.items.filter((i) => collected.has(i.id)).length;

  useEffect(() => {
    if (forceExpanded) setExpanded(true);
  }, [forceExpanded]);

  const tierPct = tierData.items.length > 0 ? (tierCollected / tierData.items.length) * 100 : 0;

  return (
    <div className="mb-2">
      <button
        className="w-full flex items-center gap-3 px-4 py-2.5 transition-all hover:brightness-110"
        style={{
          background: `linear-gradient(90deg, ${tierData.color}1a 0%, ${tierData.color}08 55%, transparent 100%)`,
          borderLeft: `3px solid ${tierData.color}`,
          borderBottom: `1px solid ${tierData.color}1a`,
          borderTop: `1px solid ${tierData.color}0d`,
          cursor: 'pointer',
          borderRadius: expanded ? '4px 4px 0 0' : '4px',
        }}
        onClick={() => setExpanded((v) => !v)}
      >
        <span
          className="font-bold tracking-widest uppercase text-sm"
          style={{ color: tierData.color, fontFamily: "'Courier New', Courier, monospace", letterSpacing: '0.14em', minWidth: 0 }}
        >
          {tierData.tier}
        </span>
        {!isPlaceholder && (
          <>
            <span
              className="text-xs px-1.5 py-0.5 rounded"
              style={{
                background: `${tierData.color}18`,
                border: `1px solid ${tierData.color}33`,
                color: tierData.color,
                fontFamily: 'monospace',
                fontSize: 10,
              }}
            >
              {tierData.items.length}
            </span>
            <div className="flex-1" />
            <div
              className="rounded-full overflow-hidden hidden sm:block"
              style={{ width: 64, height: 3, background: 'rgba(255,255,255,0.06)' }}
            >
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${tierPct}%`, background: tierData.color, opacity: 0.8 }}
              />
            </div>
            <span
              className="text-xs font-mono"
              style={{ color: tierCollected === tierData.items.length && tierData.items.length > 0 ? '#22c55e' : 'rgba(180,180,180,0.55)', minWidth: 48, textAlign: 'right' }}
            >
              {tierCollected} / {tierData.items.length}
            </span>
          </>
        )}
        <span
          className="text-xs ml-1 transition-transform duration-200 inline-block"
          style={{ color: 'rgba(160,160,160,0.4)', transform: expanded ? 'rotate(0deg)' : 'rotate(-90deg)' }}
        >
          ▼
        </span>
      </button>

      {expanded && (
        <div
          className="px-4 py-4"
          style={{
            background: 'rgba(10,10,13,0.65)',
            border: `1px solid ${tierData.color}12`,
            borderTop: 'none',
            borderRadius: '0 0 4px 4px',
          }}
        >
          {isPlaceholder ? (
            <div className="py-8 text-center font-mono text-xs tracking-widest" style={{ color: `${tierData.color}55`, letterSpacing: '0.3em' }}>
              — COMING SOON —
            </div>
          ) : (
            <div className="flex flex-wrap gap-2">
              {tierData.items.map((item) => (
                <ItemSlot key={item.id} item={item} collected={collected.has(item.id)} onToggle={onToggle} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [collected, setCollected] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'found' | 'notfound'>('all');
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [expandTick, setExpandTick] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(() => getSession());

  const loadProgress = async (uid: string) => {
    const res = await fetch(`/api/progress?username=${encodeURIComponent(uid)}`);
    if (res.ok) {
      const { items } = await res.json();
      setCollected(new Set(items as string[]));
    }
  };

  const saveProgress = async (uid: string, itemId: string, isCollected: boolean) => {
    try {
      const res = await fetch('/api/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: uid, itemId, collected: isCollected }),
      });
      if (!res.ok) console.error('saveProgress failed:', res.status);
    } catch (e) {
      console.error('saveProgress error:', e);
    }
  };

  useEffect(() => {
    if (userId) {
      loadProgress(userId).then(() => setIsLoading(false));
    } else {
      setIsLoading(false);
    }
  }, []);

  const toggleItem = useCallback((id: string) => {
    if (!userId) return;
    const isNowCollected = !collected.has(id);
    setCollected((prev) => {
      const next = new Set(prev);
      if (isNowCollected) next.add(id); else next.delete(id);
      return next;
    });
    saveProgress(userId, id, isNowCollected);
  }, [userId, collected]);

  const totalCollected = collected.size;
  const pct = TOTAL > 0 ? Math.round((totalCollected / TOTAL) * 100) : 0;
  const isFiltered = search.trim() !== '' || filterMode !== 'all';

  useEffect(() => {
    if (isFiltered) setExpandTick((t) => t + 1);
  }, [isFiltered]);

  const getFilteredItems = useCallback((items: Item[]) => {
    return items.filter((item) => {
      const matchSearch = !search.trim() || item.name.toLowerCase().includes(search.toLowerCase());
      const matchFilter =
        filterMode === 'all' ||
        (filterMode === 'found' && collected.has(item.id)) ||
        (filterMode === 'notfound' && !collected.has(item.id));
      return matchSearch && matchFilter;
    });
  }, [search, filterMode, collected]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#0a0a0a', color: '#d4d4d8' }}>
        <div className="text-center">
          <p className="text-lg font-mono tracking-widest" style={{ color: '#e8c87a', letterSpacing: '0.2em' }}>
            LOADING TRACKER...
          </p>
        </div>
      </div>
    );
  }

  if (!userId) {
    return <AuthScreen onLogin={(u) => { setUserId(u); loadProgress(u).then(() => setIsLoading(false)); }} />;
  }

  return (
    <div className="min-h-screen" style={{ background: '#0a0a0a', color: '#d4d4d8' }}>
      {/* Sticky top bar */}
      <div
        className="sticky top-0 z-40 px-4 py-3"
        style={{
          background: 'rgba(6,6,8,0.97)',
          borderBottom: '1px solid rgba(232,200,122,0.12)',
          backdropFilter: 'blur(10px)',
        }}
      >
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
            {/* Title */}
            <div className="shrink-0">
              <div className="flex items-baseline gap-2">
                <h1
                  className="text-base font-bold tracking-widest uppercase"
                  style={{ fontFamily: "'Courier New', Courier, monospace", color: '#e8c87a', letterSpacing: '0.18em' }}
                >
                  Dune Awakening
                </h1>
                <span
                  className="text-xs tracking-widest uppercase"
                  style={{ color: 'rgba(232,200,122,0.45)', fontFamily: 'monospace', letterSpacing: '0.2em' }}
                >
                  Unique Tracker
                </span>
              </div>
            </div>

            {/* Progress bar */}
            <div className="flex-1 min-w-40">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-mono" style={{ color: 'rgba(200,200,200,0.55)', whiteSpace: 'nowrap' }}>
                  {totalCollected} / {TOTAL} &nbsp;({pct}%)
                </span>
              </div>
              <div className="rounded-full overflow-hidden" style={{ height: 5, background: 'rgba(255,255,255,0.06)' }}>
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${pct}%`,
                    background: 'linear-gradient(90deg, #b87333 0%, #e8c87a 100%)',
                    boxShadow: pct > 0 ? '0 0 6px rgba(232,200,122,0.35)' : 'none',
                  }}
                />
              </div>
            </div>

            {/* Search */}
            <input
              type="text"
              placeholder="Search items..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="rounded px-3 py-1.5 text-xs outline-none shrink-0"
              style={{
                background: 'rgba(25,25,30,0.9)',
                border: '1px solid rgba(232,200,122,0.18)',
                color: '#e0e0e8',
                fontFamily: 'monospace',
                width: 180,
              }}
            />

            {/* Filter buttons */}
            <div className="flex gap-1 shrink-0 items-center">
              {(['all', 'notfound', 'found'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setFilterMode(mode)}
                  className="px-2.5 py-1 rounded text-xs font-mono uppercase tracking-wider transition-all"
                  style={{
                    background: filterMode === mode ? 'rgba(232,200,122,0.12)' : 'rgba(25,25,30,0.6)',
                    border: `1px solid ${filterMode === mode ? 'rgba(232,200,122,0.45)' : 'rgba(255,255,255,0.07)'}`,
                    color: filterMode === mode ? '#e8c87a' : 'rgba(160,160,160,0.55)',
                    letterSpacing: '0.08em',
                  }}
                >
                  {mode === 'all' ? 'All' : mode === 'found' ? 'Found' : 'Not Found'}
                </button>
              ))}
              <div className="w-px h-4" style={{ background: 'rgba(255,255,255,0.1)', margin: '0 8px' }} />
              <button
                onClick={() => { clearSession(); setUserId(null); setCollected(new Set()); }}
                className="px-2.5 py-1 rounded text-xs font-mono uppercase tracking-wider transition-all"
                style={{
                  background: 'rgba(25,25,30,0.6)',
                  border: '1px solid rgba(255,255,255,0.07)',
                  color: 'rgba(160,160,160,0.55)',
                  letterSpacing: '0.08em',
                }}
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-6">
        {TIERS.map((tierData) => {
          const filteredItems = isFiltered ? getFilteredItems(tierData.items) : tierData.items;
          if (isFiltered && filteredItems.length === 0 && tierData.items.length > 0) return null;
          const displayTier = isFiltered ? { ...tierData, items: filteredItems } : tierData;

          return (
            <TierSection
              key={tierData.tier}
              tierData={displayTier}
              collected={collected}
              onToggle={toggleItem}
              forceExpanded={isFiltered ? expandTick > 0 : false}
            />
          );
        })}

        {/* Reset */}
        <div className="mt-10 mb-8 flex justify-center">
          {!showResetConfirm ? (
            <button
              onClick={() => setShowResetConfirm(true)}
              className="px-5 py-2 rounded text-xs font-mono tracking-widest uppercase transition-all hover:opacity-75"
              style={{
                background: 'rgba(35,8,8,0.55)',
                border: '1px solid rgba(200,50,50,0.2)',
                color: 'rgba(210,90,90,0.65)',
                letterSpacing: '0.14em',
              }}
            >
              Reset All Progress
            </button>
          ) : (
            <div
              className="flex items-center gap-4 px-5 py-3 rounded"
              style={{ background: 'rgba(35,8,8,0.8)', border: '1px solid rgba(200,50,50,0.35)' }}
            >
              <span className="text-xs font-mono" style={{ color: 'rgba(215,110,110,0.9)' }}>
                Reset all {totalCollected} collected items?
              </span>
              <button
                onClick={async () => {
                  if (userId) {
                    // Reset all: refetch will show empty after clearing
      await fetch(`/api/progress/reset?username=${encodeURIComponent(userId ?? '')}`, { method: 'DELETE' });
                    setCollected(new Set());
                  }
                  setShowResetConfirm(false);
                }}
                className="px-3 py-1 rounded text-xs font-mono uppercase transition-all hover:opacity-80"
                style={{ background: 'rgba(160,25,25,0.3)', border: '1px solid rgba(200,50,50,0.45)', color: '#f87171' }}
              >
                Confirm
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-3 py-1 rounded text-xs font-mono uppercase transition-all hover:opacity-80"
                style={{ background: 'rgba(25,25,30,0.6)', border: '1px solid rgba(255,255,255,0.09)', color: 'rgba(170,170,170,0.65)' }}
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
