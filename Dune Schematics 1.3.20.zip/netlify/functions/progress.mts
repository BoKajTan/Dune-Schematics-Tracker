import type { Config } from "@netlify/functions";
import { neon } from "@neondatabase/serverless";

export default async (req: Request) => {
  const sql = neon(process.env.NETLIFY_DATABASE_URL!);

  await sql`CREATE TABLE IF NOT EXISTS user_progress (id SERIAL PRIMARY KEY, username TEXT NOT NULL, item_id TEXT NOT NULL, collected_at TIMESTAMP DEFAULT NOW(), UNIQUE(username, item_id))`;

  const url = new URL(req.url);

  if (req.method === "GET") {
    const username = url.searchParams.get("username");
    if (!username) return Response.json({ error: "Username required" }, { status: 400 });
    const rows = await sql`SELECT item_id FROM user_progress WHERE username = ${username}`;
    return Response.json({ items: rows.map((r: any) => r.item_id) });
  }

  if (req.method === "DELETE") {
    const username = url.searchParams.get("username");
    if (!username) return Response.json({ error: "Username required" }, { status: 400 });
    await sql`DELETE FROM user_progress WHERE username = ${username}`;
    return Response.json({ ok: true });
  }

  if (req.method === "POST") {
    let body: { username?: string; itemId?: string; collected?: boolean };
    try { body = await req.json(); }
    catch { return Response.json({ error: "Invalid request body" }, { status: 400 }); }

    const { username, itemId, collected } = body;
    if (!username || !itemId) return Response.json({ error: "username and itemId required" }, { status: 400 });

    if (collected) {
      await sql`INSERT INTO user_progress (username, item_id) VALUES (${username}, ${itemId}) ON CONFLICT DO NOTHING`;
    } else {
      await sql`DELETE FROM user_progress WHERE username = ${username} AND item_id = ${itemId}`;
    }
    return Response.json({ ok: true });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: ["/api/progress", "/api/progress/reset"],
};
