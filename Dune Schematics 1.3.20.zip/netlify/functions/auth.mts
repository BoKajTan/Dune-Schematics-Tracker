import type { Config } from "@netlify/functions";
import bcrypt from "bcryptjs";
import { neon } from "@neondatabase/serverless";

export default async (req: Request) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const sql = neon(process.env.NETLIFY_DATABASE_URL!);

  // Ensure tables exist
  await sql`CREATE TABLE IF NOT EXISTS accounts (id SERIAL PRIMARY KEY, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, created_at TIMESTAMP DEFAULT NOW())`;
  await sql`CREATE TABLE IF NOT EXISTS user_progress (id SERIAL PRIMARY KEY, username TEXT NOT NULL, item_id TEXT NOT NULL, collected_at TIMESTAMP DEFAULT NOW(), UNIQUE(username, item_id))`;

  const url = new URL(req.url);
  const action = url.pathname.split("/").pop();

  let body: { username?: string; password?: string };
  try { body = await req.json(); }
  catch { return Response.json({ error: "Invalid request body" }, { status: 400 }); }

  const username = (body.username ?? "").trim().toLowerCase();
  const password = body.password ?? "";

  if (!username || !password) return Response.json({ error: "Username and password required" }, { status: 400 });
  if (username.length < 2) return Response.json({ error: "Username must be at least 2 characters" }, { status: 400 });

  if (action === "register") {
    if (password.length < 4) return Response.json({ error: "Password must be at least 4 characters" }, { status: 400 });

    const existing = await sql`SELECT username FROM accounts WHERE username = ${username}`;
    if (existing.length > 0) return Response.json({ error: "Username already taken" }, { status: 409 });

    const passwordHash = await bcrypt.hash(password, 10);
    await sql`INSERT INTO accounts (username, password_hash) VALUES (${username}, ${passwordHash})`;
    return Response.json({ username }, { status: 201 });
  }

  if (action === "login") {
    const rows = await sql`SELECT password_hash FROM accounts WHERE username = ${username}`;
    if (rows.length === 0) return Response.json({ error: "Unknown username" }, { status: 401 });

    const valid = await bcrypt.compare(password, rows[0].password_hash);
    if (!valid) return Response.json({ error: "Incorrect password" }, { status: 401 });

    return Response.json({ username });
  }

  return new Response("Not found", { status: 404 });
};

export const config: Config = {
  path: ["/api/auth/register", "/api/auth/login"],
};
